# 云智ERP — 修复与补全版

本压缩包是基于原始上传代码，应用了本次对话中讨论过的**全部已确认修复**，并补齐了此前约 65% 处于空占位状态的功能页面后打包的完整前端项目。**已在本地实际执行 `npm install && npm run build` 验证过可以正常构建通过**，`npm run dev` 也可正常启动开发服务器。

## 快速启动

```bash
npm install
cp .env.example .env      # 然后把里面的 Supabase URL / anon key 换成你自己项目的
npm run dev                # 开发模式，默认 http://localhost:3000
npm run build               # 生产构建，产物在 dist/
```

> ⚠️ **重要**：本项目前端可以独立运行、构建、跳转所有路由，但**没有包含任何 Supabase 数据库表结构**。新补齐的模块（采购、仓库、OA、系统管理等）引用的数据表（如 `purchase_requisitions`、`warehouses`、`stocktakes`、`announcements`、`todos`、`dict_items`、`system_config` 等）需要你在自己的 Supabase 项目里建表 + 配置 RLS 策略后，相关页面的增删改查才能真正跑通；在没有配置 Supabase 之前，页面能打开、能看到 UI，但接口调用会报错（这是正常现象，不是本次交付的 bug）。

## 本次修复清单（对照此前对话中的编号）

### 🔴 Critical
| 编号 | 问题 | 修复位置 |
|---|---|---|
| C1 | 权限体系（RBAC）从未真正生效，任何登录用户可访问所有页面/菜单 | `router/index.js`（路由守卫加 `meta.module` 校验）+ `SidebarMenu.vue`（菜单按权限过滤） |
| C2 | 通知抽屉点击铃铛无反应（事件链断开） | `MainLayout.vue`（补上 `v-model` 绑定 + 事件监听） |
| C3 | 点击单条通知报错（`markRead` 方法不存在） | `stores/notification.js` |
| C4 | 页面卸载报错（`unsubscribe` 方法不存在） | `stores/notification.js` |
| C5 | 深色主题从未真正应用，卡片/表格与页面背景色不一致 | `App.vue`（根据 `appStore.darkMode` 切换 `dark-mode` class） |
| C6 | 库存预警查询使用了不存在的 `supabase.raw()`，必定报错 | `api/wms.js` |
| C7 | `ElMessageBox.confirm()`/`validate()` 大面积未捕获取消/校验失败异常（系统性问题） | 新增 `utils/confirm.js`，应用到 `useForm.js`、`useTable.js`、`Employees.vue`、`Expenses.vue`、`TopBar.vue`、`Login.vue` 等所有相关位置 |
| C8 | 销售漏斗查询逻辑写反，只返回"已成交"阶段的数据 | `api/crm.js` |

### 🟠 High
| 编号 | 问题 | 修复位置 |
|---|---|---|
| H1 | 审批中心是空占位页，但审批引擎API已完整实现 | 新建 `views/system/Approval.vue` |
| H2 | 已"完成"页面大多使用硬编码模拟数据，未接入真实API | 代表性修复：`views/crm/SalesOrders.vue` 已完全接入 `salesOrdersApi` |
| H3 | 登录/登出循环会累积重复的 `onAuthStateChange` 监听器 | `stores/auth.js` |
| H4 | ECharts 图表实例与 resize 监听器未清理（内存泄漏） | 代表性修复：`views/dashboard/Index.vue` 已改用 `useChart` 组合式函数 |
| H5 | 路由守卫无权限校验（与 C1 同源） | 与 C1 一并在 `router/index.js` 中修复 |

### 🟡 Medium
M1（`authStore.avatar` 缺失字段）、M2（面包屑从未被赋值）、M3（全局搜索无快捷键/逻辑）、M4（标签页右键菜单是空函数）、M5（`BaseApi.update/remove` 双倍请求）、M6（审批角标硬编码）、M7（员工统计硬编码）、M8（仪表盘待办事项为假数据）、M9（手机号校验未抽成公共 validator）、M10（`useTable.handleDelete` 吞掉取消/失败信息）— **全部已修复**，具体改动见对应文件内的 `[FIX Mx]` 注释。

### 🎁 打包联调阶段额外发现并修复的问题（此前对话未覆盖）
在实际执行 `npm run build` 验证时，额外发现并修复了 2 个此前审查未捕获的真实 Bug：
1. **`BaseApi.list()` 的筛选条件从未真正生效**：原方法签名要求调用方把筛选字段包在 `{ filters: {...} }` 里，但项目里所有实际调用方（`useTable.js`、各页面）传的都是扁平参数，导致所有列表页面的筛选/搜索功能实际上从未生效过。已在 `api/base.js` 中修复为扁平参数解析方式。
2. **`bi/Index.vue` 引用的四个分析子组件路径不存在**（`./components/SalesAnalysis.vue` 等），导致生产构建直接失败。已将这 4 个文件归位到 `src/views/bi/components/` 目录下。

## 本次新增补全的功能页面（此前均为 9 行占位页）

| 模块 | 新增页面 |
|---|---|
| 人力资源 HRM | 组织架构 `Org.vue`、招聘管理 `Recruit.vue` |
| 销售 CRM | 报价管理 `Quotations.vue` |
| 采购管理 | 供应商管理 `Suppliers.vue`、采购申请 `Requisitions.vue`、采购订单 `Orders.vue` |
| 库存 WMS | 仓库管理 `Warehouses.vue`、入库单 `Inbound.vue`、出库单 `Outbound.vue`、库存盘点 `Stocktake.vue` |
| 财务管理 | 应收账款 `Receivables.vue`、应付账款 `Payables.vue`、总账凭证 `Ledger.vue`、财务报表 `Reports.vue` |
| OA办公 | 公告通知 `Announcements.vue`、会议预约 `Meetings.vue`、文件管理 `Files.vue`、待办事项 `Todos.vue`、企业知识库 `Knowledge.vue` |
| 系统管理 | 角色权限 `Roles.vue`、数据字典 `Dict.vue`、系统设置 `Settings.vue`、日志中心 `Logs.vue` |
| 工作台 | 审批中心 `Approval.vue`（H1） |

配套新增/扩展了以下 API 层文件：`api/purchase.js`（新建）、`api/oa.js`（新建）、`api/system.js`（新建），并在 `api/crm.js`、`api/employees.js`、`api/wms.js` 中分别追加了 `quotationsApi`、`recruitApi`、`warehousesApi`/`stocktakeApi`。

## 未在本次范围内的项

以下此前对话中提到的模式性问题（H2/H4 的"代表性修复"）只在**示例文件**中做了修复，尚未推广到其余同类页面，如需要可以后续再逐一处理：
- H2（页面未接入真实API）：`Customers.vue`、`Leads.vue`、`Inventory.vue`、`Payroll.vue`、`Attendance.vue`、`WorkflowDesigner.vue` 仍保留原有的本地模拟数据。
- H4（图表内存泄漏）：`bi/Index.vue`（数据分析页的 3 个图表）仍是原始的手动 `echarts.init()` 写法。
- `Messages.vue`（消息中心）此前从未在对话中被修复过，本次也维持原样（仍是占位页）。

## 目录结构

```
src/
├── api/            # Supabase 数据访问层（含新增的 purchase.js / oa.js / system.js）
├── components/
│   ├── common/     # PageHeader / CardHeader / KpiCard / StatusTag
│   └── layout/     # MainLayout / TopBar / SidebarMenu / TabsBar / NotificationDrawer / SidebarLogo
├── composables/     # useTable / useForm / useChart / usePermission
├── router/          # 路由 + 权限守卫
├── stores/          # Pinia：app / auth / notification
├── styles/          # index.scss / variables.scss / element-override.scss
├── utils/           # format.js / confirm.js（新增）/ validators.js（新增）
└── views/           # 按模块分目录的所有页面
```
