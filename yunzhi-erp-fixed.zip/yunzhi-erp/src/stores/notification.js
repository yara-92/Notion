import { defineStore } from 'pinia'
import { supabase, subscribeToNotifications } from '@/supabase'

export const useNotificationStore = defineStore('notification', {
  state: () => ({ list: [], unreadCount: 0, subscription: null }),
  actions: {
    async fetch(userId) {
      const { data } = await supabase.from('notifications')
        .select('*').eq('user_id', userId)
        .order('created_at', { ascending: false }).limit(50)
      this.list = data || []
      this.unreadCount = this.list.filter(n => !n.is_read).length
    },
    subscribe(userId) {
      this.subscription = subscribeToNotifications(userId, n => {
        this.list.unshift(n); this.unreadCount++
      })
    },
    // [FIX C4] MainLayout.vue 卸载时会调用 notifStore.unsubscribe()，
    // 但原来的 store 里根本没有这个方法，会直接抛出 TypeError。
    unsubscribe() {
      if (this.subscription) {
        supabase.removeChannel(this.subscription)
        this.subscription = null
      }
    },
    // [FIX C3] NotificationDrawer.vue 点击单条通知会调用 notifStore.markRead(id)，
    // 但原来的 store 只有 markAllRead()，点击任意一条通知都会直接报错。
    async markRead(id) {
      const n = this.list.find(n => n.id === id)
      if (!n || n.is_read) return
      await supabase.from('notifications').update({ is_read: true }).eq('id', id)
      n.is_read = true
      this.unreadCount = Math.max(0, this.unreadCount - 1)
    },
    async markAllRead() {
      const ids = this.list.filter(n => !n.is_read).map(n => n.id)
      if (!ids.length) return
      await supabase.from('notifications').update({ is_read: true }).in('id', ids)
      this.list.forEach(n => n.is_read = true); this.unreadCount = 0
    }
  }
})
