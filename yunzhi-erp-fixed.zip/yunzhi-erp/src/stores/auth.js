import { defineStore } from 'pinia'
import { authApi, supabase } from '@/supabase'

export const useAuthStore = defineStore('auth', {
  // [FIX H3] 新增 authListener 用于持有 onAuthStateChange 返回的订阅句柄，
  // 便于在 signOut() 时正确取消订阅，避免登录/登出循环时监听器不断累积。
  state: () => ({ user: null, profile: null, session: null, loading: false, initialized: false, authListener: null }),
  getters: {
    isAuthenticated: s => !!s.session,
    userId: s => s.user?.id,
    userName: s => s.profile?.name || s.user?.email,
    // [FIX M1] TopBar.vue 引用了 authStore.avatar，但原来的 store 里根本没有这个字段，
    // 补上 getter（依赖 users 表里的 avatar_url 列，如暂无该列可直接返回空字符串）。
    avatar: s => s.profile?.avatar_url || '',
    userRole: s => s.profile?.roles?.name || 'employee',
    isSuperAdmin: s => s.profile?.roles?.name === 'super_admin'
  },
  actions: {
    async initAuth() {
      // [FIX H3] 已经注册过监听器就不要重复注册
      if (this.authListener) { this.initialized = true; return }
      this.loading = true
      try {
        const session = await authApi.getSession()
        if (session) { this.session = session; this.user = session.user; await this.fetchProfile() }
        const { data } = authApi.onAuthStateChange(async (event, session) => {
          this.session = session; this.user = session?.user || null
          if (event === 'SIGNED_IN') await this.fetchProfile()
          else if (event === 'SIGNED_OUT') this.profile = null
        })
        this.authListener = data?.subscription || null
      } finally { this.loading = false; this.initialized = true }
    },
    async fetchProfile() {
      if (!this.user) return
      const { data } = await supabase.from('users')
        .select('*, avatar_url, roles(*), departments(id,name), positions(id,name)')
        .eq('id', this.user.id).single()
      this.profile = data
    },
    async signIn(email, password) {
      this.loading = true
      try {
        const data = await authApi.signIn(email, password)
        this.session = data.session; this.user = data.user
        await this.fetchProfile()
      } finally { this.loading = false }
    },
    async signOut() {
      await authApi.signOut()
      // [FIX H3] 登出时显式取消订阅，避免下次 initAuth() 再叠加一个新监听器
      this.authListener?.unsubscribe()
      this.$reset()
    },
    hasPermission(module, action = 'read') {
      if (this.isSuperAdmin) return true
      return this.profile?.roles?.permissions?.some(p => p.module === module && p.action === action) ?? false
    }
  }
})
