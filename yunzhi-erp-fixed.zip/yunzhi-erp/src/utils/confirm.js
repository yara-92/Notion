import { ElMessageBox } from 'element-plus'

/**
 * [FIX C7] ElMessageBox.confirm() 在用户点"取消"时会 reject 这个 Promise。
 * 项目里大量地方直接 await 而不做 try/catch，导致每次用户点取消都会产生一条
 * 未捕获的 Promise rejection。这里统一封装成 resolve(false)，调用方直接
 * `if (!(await safeConfirm(...))) return` 即可。
 */
export async function safeConfirm(message, title = '提示', options = { type: 'warning' }) {
  try {
    await ElMessageBox.confirm(message, title, options)
    return true
  } catch {
    return false
  }
}

/**
 * [FIX C7] el-form 的 validate() 在校验失败时同样会 reject，原理同上。
 */
export async function safeValidate(formRef) {
  try {
    await formRef.value.validate()
    return true
  } catch {
    return false
  }
}
