// [FIX M9] 手机号校验此前直接写死在 Employees.vue 表单规则里，无法复用，
// 且只支持中国大陆手机号。抽成公共 validator，如需支持国际号码可在此扩展。
export const CN_MOBILE_RULE = { pattern: /^1[3-9]\d{9}$/, message: '手机号格式不正确', trigger: 'blur' }
