<template>
  <el-config-provider :locale="zhCn">
    <router-view />
  </el-config-provider>
</template>

<script setup>
import zhCn from 'element-plus/es/locale/lang/zh-cn'
import { watchEffect } from 'vue'
import { useAppStore } from '@/stores/app'

// [FIX C5] 深色主题此前从未真正应用：index.scss 里定义了 .dark-mode 的变量集合，
// 但没有任何地方把这个 class 加到根节点上。这里根据 appStore.darkMode 状态同步切换，
// 使 element-override.scss 里被强制改成深色的卡片/表格背景，和页面整体背景/文字色保持一致。
const appStore = useAppStore()
watchEffect(() => {
  document.documentElement.classList.toggle('dark-mode', appStore.darkMode)
})
</script>
