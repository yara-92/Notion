<template>
  <div>
    <PageHeader title="企业知识库" :breadcrumb="['OA办公','企业知识库']">
      <template #actions>
        <el-input v-model="keyword" placeholder="搜索文章标题" prefix-icon="Search" style="width:200px" clearable @change="handleSearch" />
        <el-button type="primary" icon="Plus" @click="openForm()">新建文章</el-button>
      </template>
    </PageHeader>

    <el-row :gutter="16">
      <el-col :span="8" v-for="item in tableData" :key="item.id">
        <el-card class="doc-card" shadow="hover" @click="preview(item)">
          <h3 class="doc-title">{{ item.title }}</h3>
          <p class="doc-excerpt">{{ item.content }}</p>
          <div class="doc-foot"><span>{{ item.author?.name }}</span><span>{{ fmt.date(item.created_at) }}</span></div>
        </el-card>
      </el-col>
    </el-row>
    <el-empty v-if="!loading && !tableData.length" description="暂无文章" />

    <el-dialog v-model="previewVisible" :title="previewItem?.title" width="600px" align-center>
      <p style="white-space:pre-wrap;line-height:1.8">{{ previewItem?.content }}</p>
    </el-dialog>

    <el-dialog v-model="formVisible" title="新建文章" width="600px" align-center destroy-on-close>
      <el-form :model="formData" ref="formRef" label-width="80px">
        <el-form-item label="标题" prop="title" :rules="[{ required: true, message: '请输入标题' }]"><el-input v-model="formData.title" /></el-form-item>
        <el-form-item label="内容"><el-input v-model="formData.content" type="textarea" :rows="8" /></el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="closeForm">取消</el-button>
        <el-button type="primary" :loading="formLoading" @click="submitForm">保存</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { knowledgeApi } from '@/api/oa'
import { useAuthStore } from '@/stores/auth'
import { fmt } from '@/utils/format'
import { useTable } from '@/composables/useTable'
import { useForm } from '@/composables/useForm'
import PageHeader from '@/components/common/PageHeader.vue'

const authStore = useAuthStore()
const keyword = ref('')
const previewVisible = ref(false)
const previewItem = ref(null)

const { loading, tableData, filters, load } = useTable(knowledgeApi.list.bind(knowledgeApi), { defaultPageSize: 30 })

const {
  formRef, loading: formLoading, formData, visible: formVisible,
  open: openForm, close: closeForm, submit: submitForm
} = useForm(
  { title: '', content: '' },
  async (payload) => { await knowledgeApi.create({ ...payload, author_id: authStore.userId }); load() }
)

function handleSearch(v) { filters.search = v ? { column: 'title', value: v } : null; load() }
function preview(item) { previewItem.value = item; previewVisible.value = true }

onMounted(load)
</script>

<style scoped lang="scss">
.doc-card { margin-bottom: 16px; cursor: pointer; }
.doc-title { font-size: 15px; margin: 0 0 6px; }
.doc-excerpt { font-size: 13px; color: var(--el-text-color-secondary); display: -webkit-box; -webkit-line-clamp: 3; -webkit-box-orient: vertical; overflow: hidden; min-height: 54px; }
.doc-foot { display: flex; justify-content: space-between; font-size: 12px; color: var(--el-text-color-secondary); margin-top: 8px; }
</style>
