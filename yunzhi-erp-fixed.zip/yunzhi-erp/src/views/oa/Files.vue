<template>
  <div>
    <PageHeader title="文件管理" :breadcrumb="['OA办公','文件管理']">
      <template #actions>
        <el-upload :show-file-list="false" :before-upload="handleUpload" :disabled="uploading">
          <el-button type="primary" icon="Upload" :loading="uploading">上传文件</el-button>
        </el-upload>
      </template>
    </PageHeader>

    <el-card>
      <el-table :data="tableData" v-loading="loading" stripe>
        <el-table-column prop="name" label="文件名" min-width="220" show-overflow-tooltip />
        <el-table-column label="大小" width="100"><template #default="{ row }">{{ fmt.fileSize(row.size) }}</template></el-table-column>
        <el-table-column label="上传人" prop="uploader.name" width="110" />
        <el-table-column label="上传时间" width="150"><template #default="{ row }">{{ fmt.datetime(row.created_at) }}</template></el-table-column>
        <el-table-column label="操作" width="120" fixed="right" align="center">
          <template #default="{ row }">
            <el-button size="small" text type="primary" tag="a" :href="row.url" target="_blank">下载</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { ElMessage } from 'element-plus'
import { filesApi } from '@/api/oa'
import { fmt } from '@/utils/format'
import { useTable } from '@/composables/useTable'
import PageHeader from '@/components/common/PageHeader.vue'

const uploading = ref(false)
const { loading, tableData, load } = useTable(filesApi.list.bind(filesApi), { defaultPageSize: 30 })

async function handleUpload(file) {
  uploading.value = true
  try {
    await filesApi.upload(file)
    ElMessage.success('上传成功')
    load()
  } catch (e) {
    ElMessage.error(e.message || '上传失败')
  } finally {
    uploading.value = false
  }
  return false // 阻止 el-upload 自动上传
}

onMounted(load)
</script>
