<template>
  <div>
    <PageHeader title="待办事项" :breadcrumb="['OA办公','待办事项']">
      <template #actions>
        <el-button type="primary" icon="Plus" @click="openForm()">新建待办</el-button>
      </template>
    </PageHeader>

    <el-card>
      <div v-for="item in tableData" :key="item.id" class="todo-row">
        <el-checkbox :model-value="item.done" @change="v => toggle(item, v)" />
        <span class="todo-title" :class="{ done: item.done }">{{ item.title }}</span>
        <el-tag v-if="item.priority==='high'" type="danger" size="small" effect="plain">紧急</el-tag>
        <span class="todo-due">{{ item.due_date ? fmt.date(item.due_date) : '' }}</span>
      </div>
      <el-empty v-if="!loading && !tableData.length" description="暂无待办事项" />
    </el-card>

    <el-dialog v-model="formVisible" title="新建待办" width="440px" align-center destroy-on-close>
      <el-form :model="formData" ref="formRef" label-width="80px">
        <el-form-item label="内容" prop="title" :rules="[{ required: true, message: '请输入待办内容' }]"><el-input v-model="formData.title" /></el-form-item>
        <el-form-item label="截止日期"><el-date-picker v-model="formData.due_date" type="date" style="width:100%" /></el-form-item>
        <el-form-item label="优先级">
          <el-select v-model="formData.priority" style="width:100%">
            <el-option label="普通" value="normal" /><el-option label="紧急" value="high" />
          </el-select>
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="closeForm">取消</el-button>
        <el-button type="primary" :loading="formLoading" @click="submitForm">保存</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { onMounted } from 'vue'
import { ElMessage } from 'element-plus'
import { todosApi } from '@/api/oa'
import { useAuthStore } from '@/stores/auth'
import { fmt } from '@/utils/format'
import { useTable } from '@/composables/useTable'
import { useForm } from '@/composables/useForm'
import PageHeader from '@/components/common/PageHeader.vue'

const authStore = useAuthStore()
const { loading, tableData, load } = useTable(todosApi.list.bind(todosApi), { defaultPageSize: 50 })

const {
  formRef, loading: formLoading, formData, visible: formVisible,
  open: openForm, close: closeForm, submit: submitForm
} = useForm(
  { title: '', due_date: null, priority: 'normal', done: false },
  async (payload) => { await todosApi.create({ ...payload, owner_id: authStore.userId }); load() }
)

async function toggle(item, done) {
  try { await todosApi.toggle(item.id, done); item.done = done }
  catch (e) { ElMessage.error(e.message || '更新失败') }
}

onMounted(load)
</script>

<style scoped lang="scss">
.todo-row { display: flex; align-items: center; gap: 12px; padding: 10px 4px; border-bottom: 1px solid var(--el-border-color-lighter); }
.todo-title { flex: 1; &.done { text-decoration: line-through; color: var(--el-text-color-placeholder); } }
.todo-due { font-size: 12px; color: var(--el-text-color-secondary); }
</style>
