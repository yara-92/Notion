<template>
  <div>
    <PageHeader title="公告通知" :breadcrumb="['OA办公','公告通知']">
      <template #actions>
        <el-button type="primary" icon="Plus" @click="openForm()">发布公告</el-button>
      </template>
    </PageHeader>

    <el-row :gutter="16">
      <el-col :span="8" v-for="item in tableData" :key="item.id">
        <el-card class="ann-card" shadow="hover">
          <div class="ann-head">
            <StatusTag :status="item.status" :map="{ draft:{label:'草稿',type:'info'}, published:{label:'已发布',type:'success'} }" />
            <span class="ann-date">{{ fmt.date(item.published_at || item.created_at) }}</span>
          </div>
          <h3 class="ann-title">{{ item.title }}</h3>
          <p class="ann-content">{{ item.content }}</p>
          <div class="ann-foot">
            <span>发布人：{{ item.author?.name || '-' }}</span>
            <el-button v-if="item.status==='draft'" size="small" text type="success" @click="publish(item)">发布</el-button>
          </div>
        </el-card>
      </el-col>
    </el-row>
    <el-empty v-if="!loading && !tableData.length" description="暂无公告" />

    <el-dialog v-model="formVisible" title="发布公告" width="560px" align-center destroy-on-close>
      <el-form :model="formData" ref="formRef" label-width="80px">
        <el-form-item label="标题" prop="title" :rules="[{ required: true, message: '请输入标题' }]"><el-input v-model="formData.title" /></el-form-item>
        <el-form-item label="内容"><el-input v-model="formData.content" type="textarea" :rows="5" /></el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="closeForm">取消</el-button>
        <el-button type="primary" :loading="formLoading" @click="submitForm">保存为草稿</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { onMounted } from 'vue'
import { ElMessage } from 'element-plus'
import { announcementsApi } from '@/api/oa'
import { fmt } from '@/utils/format'
import { useTable } from '@/composables/useTable'
import { useForm } from '@/composables/useForm'
import PageHeader from '@/components/common/PageHeader.vue'
import StatusTag from '@/components/common/StatusTag.vue'

const { loading, tableData, load } = useTable(announcementsApi.list.bind(announcementsApi), { defaultPageSize: 30 })

const {
  formRef, loading: formLoading, formData, visible: formVisible,
  open: openForm, close: closeForm, submit: submitForm
} = useForm(
  { title: '', content: '', status: 'draft' },
  async (payload) => { await announcementsApi.create(payload); load() }
)

async function publish(row) {
  try { await announcementsApi.publish(row.id); ElMessage.success('已发布'); load() }
  catch (e) { ElMessage.error(e.message || '发布失败') }
}

onMounted(load)
</script>

<style scoped lang="scss">
.ann-card { margin-bottom: 16px; }
.ann-head { display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px; }
.ann-date { font-size: 12px; color: var(--el-text-color-secondary); }
.ann-title { font-size: 15px; margin: 0 0 6px; }
.ann-content { font-size: 13px; color: var(--el-text-color-secondary); display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; min-height: 36px; }
.ann-foot { display: flex; justify-content: space-between; align-items: center; margin-top: 10px; font-size: 12px; color: var(--el-text-color-secondary); }
</style>
