<template>
  <div>
    <PageHeader title="会议预约" :breadcrumb="['OA办公','会议预约']">
      <template #actions>
        <el-button type="primary" icon="Plus" @click="openForm()">预约会议</el-button>
      </template>
    </PageHeader>

    <el-card>
      <el-table :data="tableData" v-loading="loading" stripe>
        <el-table-column prop="title" label="会议主题" min-width="160" show-overflow-tooltip />
        <el-table-column label="发起人" prop="organizer.name" width="110" />
        <el-table-column prop="location" label="地点" width="120" />
        <el-table-column label="开始时间" width="150"><template #default="{ row }">{{ fmt.datetime(row.start_time) }}</template></el-table-column>
        <el-table-column label="结束时间" width="150"><template #default="{ row }">{{ fmt.datetime(row.end_time) }}</template></el-table-column>
        <el-table-column prop="attendees" label="参会人数" width="90" align="center" />
      </el-table>
    </el-card>

    <el-dialog v-model="formVisible" title="预约会议" width="520px" align-center destroy-on-close>
      <el-form :model="formData" ref="formRef" label-width="90px">
        <el-form-item label="会议主题" prop="title" :rules="[{ required: true, message: '请输入主题' }]"><el-input v-model="formData.title" /></el-form-item>
        <el-form-item label="地点"><el-input v-model="formData.location" /></el-form-item>
        <el-row :gutter="16">
          <el-col :span="12"><el-form-item label="开始时间"><el-date-picker v-model="formData.start_time" type="datetime" style="width:100%" /></el-form-item></el-col>
          <el-col :span="12"><el-form-item label="结束时间"><el-date-picker v-model="formData.end_time" type="datetime" style="width:100%" /></el-form-item></el-col>
        </el-row>
        <el-form-item label="会议内容"><el-input v-model="formData.agenda" type="textarea" :rows="3" /></el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="closeForm">取消</el-button>
        <el-button type="primary" :loading="formLoading" @click="submitForm">保存</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { onMounted } from 'vue'
import { meetingsApi } from '@/api/oa'
import { useAuthStore } from '@/stores/auth'
import { fmt } from '@/utils/format'
import { useTable } from '@/composables/useTable'
import { useForm } from '@/composables/useForm'
import PageHeader from '@/components/common/PageHeader.vue'

const authStore = useAuthStore()
const { loading, tableData, load } = useTable(meetingsApi.list.bind(meetingsApi), { defaultPageSize: 30 })

const {
  formRef, loading: formLoading, formData, visible: formVisible,
  open: openForm, close: closeForm, submit: submitForm
} = useForm(
  { title: '', location: '', start_time: null, end_time: null, agenda: '' },
  async (payload) => { await meetingsApi.create({ ...payload, organizer_id: authStore.userId }); load() }
)

onMounted(load)
</script>
