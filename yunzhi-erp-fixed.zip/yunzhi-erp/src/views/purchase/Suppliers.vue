<template>
  <div>
    <PageHeader title="供应商管理" :breadcrumb="['采购管理','供应商管理']">
      <template #actions>
        <el-input v-model="keyword" placeholder="搜索供应商名称" prefix-icon="Search" style="width:200px" clearable @change="handleSearch" />
        <el-button type="primary" icon="Plus" @click="openForm()">新增供应商</el-button>
      </template>
    </PageHeader>

    <el-card>
      <el-table :data="tableData" v-loading="loading" stripe>
        <el-table-column prop="name" label="供应商名称" min-width="180" show-overflow-tooltip />
        <el-table-column prop="contact" label="联系人" width="110" />
        <el-table-column prop="phone" label="联系电话" width="130" />
        <el-table-column prop="category" label="供应类别" width="120" />
        <el-table-column label="评级" width="90" align="center">
          <template #default="{ row }"><el-tag size="small" :type="row.level==='A'?'success':row.level==='B'?'warning':'info'">{{ row.level }}</el-tag></template>
        </el-table-column>
        <el-table-column label="状态" width="90" align="center">
          <template #default="{ row }"><StatusTag :status="row.status" :map="{ active:{label:'合作中',type:'success'}, inactive:{label:'已停用',type:'info'} }" /></template>
        </el-table-column>
        <el-table-column label="操作" width="150" fixed="right" align="center">
          <template #default="{ row }">
            <el-button size="small" text type="primary" @click="openForm(row)">编辑</el-button>
            <el-button size="small" text type="danger" @click="handleDelete(row.id, suppliersApi.remove.bind(suppliersApi))">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
      <el-pagination style="margin-top:16px;justify-content:flex-end;display:flex"
        v-model:current-page="pagination.page" :total="pagination.total" :page-size="pagination.pageSize"
        layout="total, prev, pager, next" @current-change="handlePageChange" />
    </el-card>

    <el-dialog v-model="formVisible" :title="isEdit?'编辑供应商':'新增供应商'" width="520px" align-center destroy-on-close>
      <el-form :model="formData" ref="formRef" label-width="90px">
        <el-form-item label="供应商名称" prop="name" :rules="[{ required: true, message: '请输入名称' }]"><el-input v-model="formData.name" /></el-form-item>
        <el-row :gutter="16">
          <el-col :span="12"><el-form-item label="联系人"><el-input v-model="formData.contact" /></el-form-item></el-col>
          <el-col :span="12"><el-form-item label="联系电话"><el-input v-model="formData.phone" /></el-form-item></el-col>
          <el-col :span="12"><el-form-item label="供应类别"><el-input v-model="formData.category" /></el-form-item></el-col>
          <el-col :span="12"><el-form-item label="评级">
            <el-select v-model="formData.level" style="width:100%">
              <el-option label="A" value="A" /><el-option label="B" value="B" /><el-option label="C" value="C" />
            </el-select>
          </el-form-item></el-col>
        </el-row>
        <el-form-item label="地址"><el-input v-model="formData.address" type="textarea" :rows="2" /></el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="closeForm">取消</el-button>
        <el-button type="primary" :loading="formLoading" @click="submitForm">保存</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { suppliersApi } from '@/api/purchase'
import { useTable } from '@/composables/useTable'
import { useForm } from '@/composables/useForm'
import PageHeader from '@/components/common/PageHeader.vue'
import StatusTag from '@/components/common/StatusTag.vue'

const keyword = ref('')
const { loading, tableData, pagination, filters, load, handlePageChange, handleDelete } = useTable(suppliersApi.list.bind(suppliersApi))

const {
  formRef, loading: formLoading, formData, visible: formVisible, isEdit,
  open: openForm, close: closeForm, submit: submitForm
} = useForm(
  { name: '', contact: '', phone: '', category: '', level: 'B', status: 'active', address: '' },
  async (payload, editing, editId) => {
    if (editing) await suppliersApi.update(editId, payload)
    else await suppliersApi.create(payload)
    load()
  }
)

function handleSearch(v) { filters.search = v ? { column: 'name', value: v } : null; pagination.page = 1; load() }

onMounted(load)
</script>
