<template>
  <div>
    <PageHeader title="采购申请" :breadcrumb="['采购管理','采购申请']">
      <template #actions>
        <el-select v-model="filters.status" placeholder="状态" clearable style="width:120px" @change="load">
          <el-option label="待审批" value="pending" /><el-option label="已审批" value="approved" /><el-option label="已拒绝" value="rejected" />
        </el-select>
        <el-button type="primary" icon="Plus" @click="openForm()">发起申请</el-button>
      </template>
    </PageHeader>

    <el-card>
      <el-table :data="tableData" v-loading="loading" stripe>
        <el-table-column prop="req_no" label="申请单号" width="150" />
        <el-table-column label="申请人" prop="applicant.name" width="100" />
        <el-table-column label="部门" prop="departments.name" width="100" />
        <el-table-column prop="item" label="申请物品" min-width="160" show-overflow-tooltip />
        <el-table-column prop="qty" label="数量" width="80" align="center" />
        <el-table-column prop="reason" label="申请事由" min-width="160" show-overflow-tooltip />
        <el-table-column label="状态" width="100" align="center">
          <template #default="{ row }"><StatusTag :status="row.status" :map="{ pending:{label:'待审批',type:'warning'}, approved:{label:'已审批',type:'success'}, rejected:{label:'已拒绝',type:'danger'} }" /></template>
        </el-table-column>
        <el-table-column label="操作" width="150" fixed="right" align="center">
          <template #default="{ row }">
            <template v-if="row.status==='pending'">
              <el-button size="small" text type="success" @click="approve(row)">通过</el-button>
              <el-button size="small" text type="danger" @click="reject(row)">拒绝</el-button>
            </template>
          </template>
        </el-table-column>
      </el-table>
      <el-pagination style="margin-top:16px;justify-content:flex-end;display:flex"
        v-model:current-page="pagination.page" :total="pagination.total" :page-size="pagination.pageSize"
        layout="total, prev, pager, next" @current-change="handlePageChange" />
    </el-card>

    <el-dialog v-model="formVisible" title="发起采购申请" width="520px" align-center destroy-on-close>
      <el-form :model="formData" ref="formRef" label-width="90px">
        <el-form-item label="申请物品" prop="item" :rules="[{ required: true, message: '请输入物品名称' }]"><el-input v-model="formData.item" /></el-form-item>
        <el-row :gutter="16">
          <el-col :span="12"><el-form-item label="数量"><el-input-number v-model="formData.qty" :min="1" style="width:100%" /></el-form-item></el-col>
          <el-col :span="12"><el-form-item label="预估金额"><el-input-number v-model="formData.amount" :min="0" style="width:100%" /></el-form-item></el-col>
        </el-row>
        <el-form-item label="申请事由"><el-input v-model="formData.reason" type="textarea" :rows="3" /></el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="closeForm">取消</el-button>
        <el-button type="primary" :loading="formLoading" @click="submitForm">提交审批</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { onMounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { requisitionsApi } from '@/api/purchase'
import { useAuthStore } from '@/stores/auth'
import { safeConfirm } from '@/utils/confirm'
import { useTable } from '@/composables/useTable'
import { useForm } from '@/composables/useForm'
import PageHeader from '@/components/common/PageHeader.vue'
import StatusTag from '@/components/common/StatusTag.vue'

const authStore = useAuthStore()
const { loading, tableData, pagination, filters, load, handlePageChange } = useTable(requisitionsApi.list.bind(requisitionsApi))

const {
  formRef, loading: formLoading, formData, visible: formVisible,
  open: openForm, close: closeForm, submit: submitForm
} = useForm(
  { item: '', qty: 1, amount: 0, reason: '', status: 'pending' },
  async (payload) => {
    await requisitionsApi.create({ ...payload, applicant_id: authStore.userId, dept_id: authStore.profile?.dept_id })
    load()
  }
)

async function approve(row) {
  if (!(await safeConfirm(`确认通过「${row.item}」的采购申请？`))) return
  try { await requisitionsApi.approve(row.id); ElMessage.success('已审批通过'); load() }
  catch (e) { ElMessage.error(e.message || '操作失败') }
}
async function reject(row) {
  try {
    const { value } = await ElMessageBox.prompt('请输入拒绝原因', '拒绝申请', { inputPlaceholder: '原因...' })
    await requisitionsApi.reject(row.id, value)
    ElMessage.warning('已拒绝')
    load()
  } catch { /* 用户取消 */ }
}

onMounted(load)
</script>
