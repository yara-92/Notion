<template>
  <div>
    <PageHeader title="采购订单" :breadcrumb="['采购管理','采购订单']">
      <template #actions>
        <el-select v-model="filters.status" placeholder="状态" clearable style="width:130px" @change="load">
          <el-option v-for="s in statusOptions" :key="s.value" :label="s.label" :value="s.value" />
        </el-select>
        <el-button type="primary" icon="Plus" @click="openForm()">新建采购单</el-button>
      </template>
    </PageHeader>

    <el-card>
      <el-table :data="tableData" v-loading="loading" stripe>
        <el-table-column prop="po_no" label="采购单号" width="150" />
        <el-table-column label="供应商" prop="suppliers.name" min-width="160" show-overflow-tooltip />
        <el-table-column label="金额" width="130" align="right">
          <template #default="{ row }"><span style="font-weight:700">{{ fmt.money(row.amount) }}</span></template>
        </el-table-column>
        <el-table-column prop="expected_date" label="预计到货" width="110">
          <template #default="{ row }">{{ fmt.date(row.expected_date) }}</template>
        </el-table-column>
        <el-table-column label="状态" width="100" align="center">
          <template #default="{ row }"><StatusTag :status="row.status" :map="statusMap" /></template>
        </el-table-column>
        <el-table-column label="操作" width="160" fixed="right" align="center">
          <template #default="{ row }">
            <el-button v-if="row.status==='pending'" size="small" text type="success" @click="approve(row)">审批</el-button>
            <el-button v-if="row.status==='approved'" size="small" text type="warning" @click="receive(row)">确认收货</el-button>
          </template>
        </el-table-column>
      </el-table>
      <el-pagination style="margin-top:16px;justify-content:flex-end;display:flex"
        v-model:current-page="pagination.page" :total="pagination.total" :page-size="pagination.pageSize"
        layout="total, prev, pager, next" @current-change="handlePageChange" />
    </el-card>

    <el-dialog v-model="formVisible" title="新建采购订单" width="520px" align-center destroy-on-close>
      <el-form :model="formData" ref="formRef" label-width="90px">
        <el-form-item label="供应商" prop="supplier_id">
          <el-select v-model="formData.supplier_id" style="width:100%" filterable>
            <el-option v-for="s in suppliers" :key="s.id" :label="s.name" :value="s.id" />
          </el-select>
        </el-form-item>
        <el-row :gutter="16">
          <el-col :span="12"><el-form-item label="金额"><el-input-number v-model="formData.amount" :min="0" :precision="2" style="width:100%" /></el-form-item></el-col>
          <el-col :span="12"><el-form-item label="预计到货"><el-date-picker v-model="formData.expected_date" type="date" style="width:100%" /></el-form-item></el-col>
        </el-row>
        <el-form-item label="备注"><el-input v-model="formData.note" type="textarea" :rows="2" /></el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="closeForm">取消</el-button>
        <el-button type="primary" :loading="formLoading" @click="submitForm">保存</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { ElMessage } from 'element-plus'
import { purchaseOrdersApi, suppliersApi } from '@/api/purchase'
import { fmt } from '@/utils/format'
import { safeConfirm } from '@/utils/confirm'
import { useTable } from '@/composables/useTable'
import { useForm } from '@/composables/useForm'
import PageHeader from '@/components/common/PageHeader.vue'
import StatusTag from '@/components/common/StatusTag.vue'

const suppliers = ref([])
const statusOptions = [
  { label: '待审批', value: 'pending' }, { label: '已审批', value: 'approved' }, { label: '已收货', value: 'received' },
]
const statusMap = { pending: { label: '待审批', type: 'warning' }, approved: { label: '已审批', type: 'success' }, received: { label: '已收货', type: '' } }

const { loading, tableData, pagination, filters, load, handlePageChange } = useTable(purchaseOrdersApi.list.bind(purchaseOrdersApi))

const {
  formRef, loading: formLoading, formData, visible: formVisible,
  open: openForm, close: closeForm, submit: submitForm
} = useForm(
  { supplier_id: null, amount: 0, expected_date: null, note: '', status: 'pending' },
  async (payload) => { await purchaseOrdersApi.create(payload); load() }
)

async function approve(row) {
  if (!(await safeConfirm(`确认审批通过采购单 ${row.po_no}？`))) return
  try { await purchaseOrdersApi.approve(row.id); ElMessage.success('已审批通过'); load() }
  catch (e) { ElMessage.error(e.message || '操作失败') }
}
async function receive(row) {
  if (!(await safeConfirm(`确认 ${row.po_no} 已到货入库？`))) return
  try { await purchaseOrdersApi.receive(row.id); ElMessage.success('已确认收货'); load() }
  catch (e) { ElMessage.error(e.message || '操作失败') }
}

onMounted(async () => {
  const res = await suppliersApi.list({ pageSize: 100 })
  suppliers.value = res.data
  load()
})
</script>
