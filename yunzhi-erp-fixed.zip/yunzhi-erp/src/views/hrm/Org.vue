<template>
  <div>
    <PageHeader title="组织架构" :breadcrumb="['人力资源','组织架构']">
      <template #actions>
        <el-button icon="Refresh" @click="load">刷新</el-button>
      </template>
    </PageHeader>
    <el-card v-loading="loading">
      <el-tree :data="tree" node-key="id" default-expand-all :props="{ label: 'name', children: 'children' }">
        <template #default="{ data }">
          <div class="org-node">
            <span class="org-name">{{ data.name }}</span>
            <span v-if="data.manager?.name" class="org-manager">负责人：{{ data.manager.name }}</span>
          </div>
        </template>
      </el-tree>
      <el-empty v-if="!loading && !tree.length" description="暂无组织架构数据" />
    </el-card>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { ElMessage } from 'element-plus'
import { employeesApi } from '@/api/employees'
import PageHeader from '@/components/common/PageHeader.vue'

const loading = ref(false)
const tree = ref([])

async function load() {
  loading.value = true
  try { tree.value = await employeesApi.getOrgTree() }
  catch (e) { ElMessage.error(e.message || '加载组织架构失败') }
  finally { loading.value = false }
}

onMounted(load)
</script>

<style scoped lang="scss">
.org-node { display: flex; align-items: center; gap: 10px; padding: 2px 0; }
.org-name { font-weight: 500; }
.org-manager { font-size: 12px; color: var(--el-text-color-secondary); }
</style>
