<template>
  <div>
    <PageHeader title="招聘管理" :breadcrumb="['人力资源','招聘管理']">
      <template #actions>
        <el-select v-model="filters.status" placeholder="状态" clearable style="width:120px" @change="load">
          <el-option label="招聘中" value="open" /><el-option label="已关闭" value="closed" />
        </el-select>
        <el-button type="primary" icon="Plus" @click="openForm()">新增职位</el-button>
      </template>
    </PageHeader>

    <el-card>
      <el-table :data="tableData" v-loading="loading" stripe>
        <el-table-column prop="title" label="职位名称" min-width="140" />
        <el-table-column label="部门" prop="departments.name" width="120" />
        <el-table-column prop="headcount" label="招聘人数" width="100" align="center" />
        <el-table-column label="薪资范围" width="160">
          <template #default="{ row }">{{ fmt.money(row.salary_min) }} - {{ fmt.money(row.salary_max) }}</template>
        </el-table-column>
        <el-table-column label="状态" width="100" align="center">
          <template #default="{ row }"><StatusTag :status="row.status" :map="{ open:{label:'招聘中',type:'success'}, closed:{label:'已关闭',type:'info'} }" /></template>
        </el-table-column>
        <el-table-column prop="created_at" label="发布时间" width="120">
          <template #default="{ row }">{{ fmt.date(row.created_at) }}</template>
        </el-table-column>
        <el-table-column label="操作" width="150" fixed="right" align="center">
          <template #default="{ row }">
            <el-button size="small" text type="primary" @click="openForm(row)">编辑</el-button>
            <el-button size="small" text type="danger" @click="handleDelete(row.id, recruitApi.remove.bind(recruitApi))">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
      <el-pagination style="margin-top:16px;justify-content:flex-end;display:flex"
        v-model:current-page="pagination.page" :total="pagination.total" :page-size="pagination.pageSize"
        layout="total, prev, pager, next" @current-change="handlePageChange" />
    </el-card>

    <el-dialog v-model="formVisible" :title="isEdit?'编辑职位':'新增职位'" width="520px" align-center destroy-on-close>
      <el-form :model="formData" ref="formRef" label-width="90px">
        <el-form-item label="职位名称" prop="title" :rules="[{ required: true, message: '请输入职位名称' }]"><el-input v-model="formData.title" /></el-form-item>
        <el-form-item label="部门" prop="dept_id">
          <el-select v-model="formData.dept_id" style="width:100%">
            <el-option v-for="d in depts" :key="d.id" :label="d.name" :value="d.id" />
          </el-select>
        </el-form-item>
        <el-row :gutter="16">
          <el-col :span="12"><el-form-item label="招聘人数"><el-input-number v-model="formData.headcount" :min="1" style="width:100%" /></el-form-item></el-col>
          <el-col :span="12"><el-form-item label="状态">
            <el-select v-model="formData.status" style="width:100%">
              <el-option label="招聘中" value="open" /><el-option label="已关闭" value="closed" />
            </el-select>
          </el-form-item></el-col>
          <el-col :span="12"><el-form-item label="最低薪资"><el-input-number v-model="formData.salary_min" :min="0" style="width:100%" /></el-form-item></el-col>
          <el-col :span="12"><el-form-item label="最高薪资"><el-input-number v-model="formData.salary_max" :min="0" style="width:100%" /></el-form-item></el-col>
        </el-row>
        <el-form-item label="职位描述"><el-input v-model="formData.description" type="textarea" :rows="3" /></el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="closeForm">取消</el-button>
        <el-button type="primary" :loading="formLoading" @click="submitForm">保存</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { recruitApi } from '@/api/employees'
import { supabase } from '@/supabase'
import { fmt } from '@/utils/format'
import { useTable } from '@/composables/useTable'
import { useForm } from '@/composables/useForm'
import PageHeader from '@/components/common/PageHeader.vue'
import StatusTag from '@/components/common/StatusTag.vue'

const depts = ref([])

const { loading, tableData, pagination, filters, load, handlePageChange, handleDelete } = useTable(recruitApi.list.bind(recruitApi))

const {
  formRef, loading: formLoading, formData, visible: formVisible, isEdit,
  open: openForm, close: closeForm, submit: submitForm
} = useForm(
  { title: '', dept_id: null, headcount: 1, status: 'open', salary_min: 0, salary_max: 0, description: '' },
  async (payload, editing, editId) => {
    if (editing) await recruitApi.update(editId, payload)
    else await recruitApi.create(payload)
    load()
  }
)

onMounted(async () => {
  const { data } = await supabase.from('departments').select('id,name').eq('status', 'active')
  depts.value = data || []
  load()
})
</script>
