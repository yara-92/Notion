<template>
  <div>
    <PageHeader title="库存盘点" :breadcrumb="['库存WMS','库存盘点']">
      <template #actions>
        <el-button type="primary" icon="Plus" @click="openForm()">发起盘点</el-button>
      </template>
    </PageHeader>

    <el-card>
      <el-table :data="tableData" v-loading="loading" stripe>
        <el-table-column prop="stocktake_no" label="盘点单号" width="160" />
        <el-table-column label="仓库" prop="warehouses.name" width="130" />
        <el-table-column prop="planned_date" label="计划日期" width="110">
          <template #default="{ row }">{{ fmt.date(row.planned_date) }}</template>
        </el-table-column>
        <el-table-column label="状态" width="110" align="center">
          <template #default="{ row }"><StatusTag :status="row.status" :map="{ pending:{label:'待开始',type:'info'}, in_progress:{label:'盘点中',type:'warning'}, completed:{label:'已完成',type:'success'} }" /></template>
        </el-table-column>
        <el-table-column label="操作" width="180" fixed="right" align="center">
          <template #default="{ row }">
            <el-button v-if="row.status==='pending'" size="small" text type="warning" @click="start(row)">开始盘点</el-button>
            <el-button v-if="row.status==='in_progress'" size="small" text type="success" @click="complete(row)">完成盘点</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <el-dialog v-model="formVisible" title="发起盘点" width="460px" align-center destroy-on-close>
      <el-form :model="formData" ref="formRef" label-width="90px">
        <el-form-item label="仓库" prop="warehouse_id">
          <el-select v-model="formData.warehouse_id" style="width:100%"><el-option v-for="w in warehouses" :key="w.id" :label="w.name" :value="w.id" /></el-select>
        </el-form-item>
        <el-form-item label="计划日期"><el-date-picker v-model="formData.planned_date" type="date" style="width:100%" /></el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="closeForm">取消</el-button>
        <el-button type="primary" :loading="formLoading" @click="submitForm">保存</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { ElMessage } from 'element-plus'
import { stocktakeApi, warehousesApi } from '@/api/wms'
import { fmt } from '@/utils/format'
import { safeConfirm } from '@/utils/confirm'
import { useTable } from '@/composables/useTable'
import { useForm } from '@/composables/useForm'
import PageHeader from '@/components/common/PageHeader.vue'
import StatusTag from '@/components/common/StatusTag.vue'

const warehouses = ref([])
const { loading, tableData, load } = useTable(stocktakeApi.list.bind(stocktakeApi), { defaultPageSize: 50 })

const {
  formRef, loading: formLoading, formData, visible: formVisible,
  open: openForm, close: closeForm, submit: submitForm
} = useForm(
  { warehouse_id: null, planned_date: null, status: 'pending' },
  async (payload) => { await stocktakeApi.create(payload); load() }
)

async function start(row) {
  if (!(await safeConfirm(`确认开始盘点「${row.stocktake_no}」？`))) return
  try { await stocktakeApi.start(row.id); ElMessage.success('盘点已开始'); load() }
  catch (e) { ElMessage.error(e.message || '操作失败') }
}
async function complete(row) {
  if (!(await safeConfirm(`确认完成盘点「${row.stocktake_no}」？`))) return
  try { await stocktakeApi.complete(row.id); ElMessage.success('盘点已完成'); load() }
  catch (e) { ElMessage.error(e.message || '操作失败') }
}

onMounted(async () => {
  const res = await warehousesApi.list({ pageSize: 100 })
  warehouses.value = res.data
  load()
})
</script>
