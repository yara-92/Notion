<template>
  <div>
    <PageHeader title="入库单" :breadcrumb="['库存WMS','入库单']">
      <template #actions>
        <el-button type="primary" icon="Plus" @click="dialogVisible = true">新建入库单</el-button>
      </template>
    </PageHeader>

    <el-card>
      <el-table :data="tableData" v-loading="loading" stripe>
        <el-table-column prop="in_no" label="入库单号" width="150" />
        <el-table-column label="仓库" prop="warehouses.name" width="120" />
        <el-table-column label="产品" prop="products.name" min-width="140" show-overflow-tooltip />
        <el-table-column prop="qty" label="数量" width="90" align="center" />
        <el-table-column prop="created_at" label="创建时间" width="150">
          <template #default="{ row }">{{ fmt.datetime(row.created_at) }}</template>
        </el-table-column>
        <el-table-column label="状态" width="100" align="center">
          <template #default="{ row }"><StatusTag :status="row.status" :map="{ pending:{label:'待入库',type:'warning'}, completed:{label:'已入库',type:'success'} }" /></template>
        </el-table-column>
        <el-table-column label="操作" width="120" fixed="right" align="center">
          <template #default="{ row }">
            <el-button v-if="row.status==='pending'" size="small" text type="success" @click="confirmInbound(row)">确认入库</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <el-dialog v-model="dialogVisible" title="新建入库单" width="480px" align-center destroy-on-close>
      <el-form :model="form" label-width="90px">
        <el-form-item label="仓库"><el-select v-model="form.warehouse_id" style="width:100%"><el-option v-for="w in warehouses" :key="w.id" :label="w.name" :value="w.id" /></el-select></el-form-item>
        <el-form-item label="产品"><el-select v-model="form.product_id" style="width:100%" filterable><el-option v-for="p in products" :key="p.id" :label="p.name" :value="p.id" /></el-select></el-form-item>
        <el-form-item label="数量"><el-input-number v-model="form.qty" :min="1" style="width:100%" /></el-form-item>
        <el-form-item label="来源供应商"><el-input v-model="form.supplier" /></el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="dialogVisible=false">取消</el-button>
        <el-button type="primary" :loading="submitting" @click="submit">提交</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { ElMessage } from 'element-plus'
import { transactionsApi, warehousesApi } from '@/api/wms'
import { supabase } from '@/supabase'
import { fmt } from '@/utils/format'
import { safeConfirm } from '@/utils/confirm'
import { useTable } from '@/composables/useTable'
import PageHeader from '@/components/common/PageHeader.vue'
import StatusTag from '@/components/common/StatusTag.vue'

const warehouses = ref([])
const products = ref([])
const dialogVisible = ref(false)
const submitting = ref(false)
const form = ref({ warehouse_id: null, product_id: null, qty: 1, supplier: '' })

const { loading, tableData, load } = useTable(transactionsApi.list.bind(transactionsApi), { defaultPageSize: 50 })

async function submit() {
  submitting.value = true
  try {
    await transactionsApi.inbound(form.value)
    ElMessage.success('入库单已创建')
    dialogVisible.value = false
    load()
  } catch (e) { ElMessage.error(e.message || '创建失败') }
  finally { submitting.value = false }
}

async function confirmInbound(row) {
  if (!(await safeConfirm(`确认「${row.in_no}」已完成入库？`))) return
  try { await transactionsApi.update(row.id, { status: 'completed' }); ElMessage.success('已完成入库'); load() }
  catch (e) { ElMessage.error(e.message || '操作失败') }
}

onMounted(async () => {
  const [wRes, pRes] = await Promise.all([
    warehousesApi.list({ pageSize: 100 }),
    supabase.from('products').select('id,name')
  ])
  warehouses.value = wRes.data
  products.value = pRes.data || []
  load()
})
</script>
