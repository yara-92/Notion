<template>
  <div>
    <PageHeader title="仓库管理" :breadcrumb="['库存WMS','仓库管理']">
      <template #actions>
        <el-button type="primary" icon="Plus" @click="openForm()">新增仓库</el-button>
      </template>
    </PageHeader>

    <el-card>
      <el-table :data="tableData" v-loading="loading" stripe>
        <el-table-column prop="name" label="仓库名称" min-width="140" />
        <el-table-column prop="address" label="地址" min-width="200" show-overflow-tooltip />
        <el-table-column label="负责人" prop="manager.name" width="110" />
        <el-table-column prop="capacity" label="容量(㎡)" width="100" align="center" />
        <el-table-column label="状态" width="90" align="center">
          <template #default="{ row }"><StatusTag :status="row.status" :map="{ active:{label:'启用',type:'success'}, inactive:{label:'停用',type:'info'} }" /></template>
        </el-table-column>
        <el-table-column label="操作" width="150" fixed="right" align="center">
          <template #default="{ row }">
            <el-button size="small" text type="primary" @click="openForm(row)">编辑</el-button>
            <el-button size="small" text type="danger" @click="handleDelete(row.id, warehousesApi.remove.bind(warehousesApi))">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <el-dialog v-model="formVisible" :title="isEdit?'编辑仓库':'新增仓库'" width="480px" align-center destroy-on-close>
      <el-form :model="formData" ref="formRef" label-width="90px">
        <el-form-item label="仓库名称" prop="name" :rules="[{ required: true, message: '请输入名称' }]"><el-input v-model="formData.name" /></el-form-item>
        <el-form-item label="地址"><el-input v-model="formData.address" /></el-form-item>
        <el-form-item label="容量(㎡)"><el-input-number v-model="formData.capacity" :min="0" style="width:100%" /></el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="closeForm">取消</el-button>
        <el-button type="primary" :loading="formLoading" @click="submitForm">保存</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { onMounted } from 'vue'
import { warehousesApi } from '@/api/wms'
import { useTable } from '@/composables/useTable'
import { useForm } from '@/composables/useForm'
import PageHeader from '@/components/common/PageHeader.vue'
import StatusTag from '@/components/common/StatusTag.vue'

const { loading, tableData, load, handleDelete } = useTable(warehousesApi.list.bind(warehousesApi), { defaultPageSize: 100 })

const {
  formRef, loading: formLoading, formData, visible: formVisible, isEdit,
  open: openForm, close: closeForm, submit: submitForm
} = useForm(
  { name: '', address: '', capacity: 0, status: 'active' },
  async (payload, editing, editId) => {
    if (editing) await warehousesApi.update(editId, payload)
    else await warehousesApi.create(payload)
    load()
  }
)

onMounted(load)
</script>
