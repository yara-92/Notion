<template>
  <div>
    <PageHeader title="数据字典" :breadcrumb="['系统管理','数据字典']">
      <template #actions>
        <el-input v-model="keyword" placeholder="搜索字典类型" prefix-icon="Search" style="width:180px" clearable @change="handleSearch" />
        <el-button type="primary" icon="Plus" @click="openForm()">新增字典项</el-button>
      </template>
    </PageHeader>

    <el-card>
      <el-table :data="tableData" v-loading="loading" stripe>
        <el-table-column prop="dict_type" label="字典类型" width="140" />
        <el-table-column prop="label" label="字典标签" width="160" />
        <el-table-column prop="value" label="字典值" width="140" />
        <el-table-column prop="sort_order" label="排序" width="80" align="center" />
        <el-table-column label="状态" width="90" align="center">
          <template #default="{ row }"><StatusTag :status="row.status" :map="{ active:{label:'启用',type:'success'}, inactive:{label:'停用',type:'info'} }" /></template>
        </el-table-column>
        <el-table-column label="操作" width="150" fixed="right" align="center">
          <template #default="{ row }">
            <el-button size="small" text type="primary" @click="openForm(row)">编辑</el-button>
            <el-button size="small" text type="danger" @click="handleDelete(row.id, dictApi.remove.bind(dictApi))">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
      <el-pagination style="margin-top:16px;justify-content:flex-end;display:flex"
        v-model:current-page="pagination.page" :total="pagination.total" :page-size="pagination.pageSize"
        layout="total, prev, pager, next" @current-change="handlePageChange" />
    </el-card>

    <el-dialog v-model="formVisible" :title="isEdit?'编辑字典项':'新增字典项'" width="460px" align-center destroy-on-close>
      <el-form :model="formData" ref="formRef" label-width="90px">
        <el-form-item label="字典类型" prop="dict_type" :rules="[{ required: true, message: '请输入类型' }]"><el-input v-model="formData.dict_type" /></el-form-item>
        <el-form-item label="字典标签" prop="label"><el-input v-model="formData.label" /></el-form-item>
        <el-form-item label="字典值" prop="value"><el-input v-model="formData.value" /></el-form-item>
        <el-form-item label="排序"><el-input-number v-model="formData.sort_order" :min="0" style="width:100%" /></el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="closeForm">取消</el-button>
        <el-button type="primary" :loading="formLoading" @click="submitForm">保存</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { dictApi } from '@/api/system'
import { useTable } from '@/composables/useTable'
import { useForm } from '@/composables/useForm'
import PageHeader from '@/components/common/PageHeader.vue'
import StatusTag from '@/components/common/StatusTag.vue'

const keyword = ref('')
const { loading, tableData, pagination, filters, load, handlePageChange, handleDelete } = useTable(dictApi.list.bind(dictApi))

const {
  formRef, loading: formLoading, formData, visible: formVisible, isEdit,
  open: openForm, close: closeForm, submit: submitForm
} = useForm(
  { dict_type: '', label: '', value: '', sort_order: 0, status: 'active' },
  async (payload, editing, editId) => {
    if (editing) await dictApi.update(editId, payload)
    else await dictApi.create(payload)
    load()
  }
)

function handleSearch(v) { filters.search = v ? { column: 'dict_type', value: v } : null; pagination.page = 1; load() }

onMounted(load)
</script>
