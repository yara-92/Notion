<template>
  <div>
    <PageHeader title="系统设置" :breadcrumb="['系统管理','系统设置']" />
    <el-card v-loading="loading" style="max-width:600px">
      <el-form :model="form" label-width="110px">
        <el-form-item label="系统名称"><el-input v-model="form.site_name" /></el-form-item>
        <el-form-item label="Logo地址"><el-input v-model="form.logo_url" /></el-form-item>
        <el-form-item label="默认分页大小"><el-input-number v-model="form.default_page_size" :min="10" :max="100" :step="10" /></el-form-item>
        <el-form-item label="启用深色模式"><el-switch v-model="form.default_dark_mode" /></el-form-item>
        <el-form-item>
          <el-button type="primary" :loading="saving" @click="save">保存设置</el-button>
        </el-form-item>
      </el-form>
    </el-card>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { ElMessage } from 'element-plus'
import { settingsApi } from '@/api/system'
import PageHeader from '@/components/common/PageHeader.vue'

const loading = ref(false)
const saving = ref(false)
const form = ref({ site_name: '', logo_url: '', default_page_size: 20, default_dark_mode: true })

async function load() {
  loading.value = true
  try { form.value = { ...form.value, ...(await settingsApi.get()) } }
  catch (e) { ElMessage.error(e.message || '加载设置失败') }
  finally { loading.value = false }
}

async function save() {
  saving.value = true
  try { await settingsApi.update(form.value); ElMessage.success('设置已保存') }
  catch (e) { ElMessage.error(e.message || '保存失败') }
  finally { saving.value = false }
}

onMounted(load)
</script>
