<template>
  <div>
    <PageHeader title="日志中心" :breadcrumb="['系统管理','日志中心']">
      <template #actions>
        <el-select v-model="filters.action" placeholder="操作类型" clearable style="width:130px" @change="load">
          <el-option label="创建" value="CREATE" /><el-option label="更新" value="UPDATE" /><el-option label="删除" value="DELETE" />
        </el-select>
        <el-select v-model="filters.module" placeholder="模块" clearable style="width:140px" @change="load">
          <el-option v-for="m in modules" :key="m" :label="m" :value="m" />
        </el-select>
      </template>
    </PageHeader>

    <el-card>
      <el-table :data="tableData" v-loading="loading" stripe>
        <el-table-column label="操作人" prop="user.name" width="110" />
        <el-table-column prop="action" label="操作类型" width="100">
          <template #default="{ row }">
            <el-tag size="small" :type="row.action==='DELETE'?'danger':row.action==='CREATE'?'success':'warning'">{{ row.action }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="module" label="所属模块" width="140" />
        <el-table-column prop="resource_id" label="资源ID" width="100" />
        <el-table-column label="操作时间" width="160"><template #default="{ row }">{{ fmt.datetime(row.created_at) }}</template></el-table-column>
      </el-table>
      <el-pagination style="margin-top:16px;justify-content:flex-end;display:flex"
        v-model:current-page="pagination.page" :total="pagination.total" :page-size="pagination.pageSize"
        layout="total, prev, pager, next" @current-change="handlePageChange" />
    </el-card>
  </div>
</template>

<script setup>
import { onMounted } from 'vue'
import { logsApi } from '@/api/system'
import { fmt } from '@/utils/format'
import { useTable } from '@/composables/useTable'
import PageHeader from '@/components/common/PageHeader.vue'

const modules = ['customers', 'opportunities', 'sales_orders', 'employees', 'expense_reports', 'inventory']
const { loading, tableData, pagination, filters, load, handlePageChange } = useTable(logsApi.list.bind(logsApi))

onMounted(load)
</script>
