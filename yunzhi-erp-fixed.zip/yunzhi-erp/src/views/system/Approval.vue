<template>
  <div>
    <PageHeader title="审批中心" :breadcrumb="['工作台','审批中心']" />
    <el-card>
      <el-table :data="pending" v-loading="loading" stripe>
        <el-table-column prop="template.name" label="流程类型" width="140" />
        <el-table-column prop="applicant.name" label="申请人" width="120" />
        <el-table-column prop="created_at" label="提交时间" width="160">
          <template #default="{ row }">{{ fmt.datetime(row.created_at) }}</template>
        </el-table-column>
        <el-table-column label="操作" width="160" fixed="right" align="center">
          <template #default="{ row }">
            <el-button size="small" text type="success" @click="handleApprove(row)">通过</el-button>
            <el-button size="small" text type="danger" @click="handleReject(row)">拒绝</el-button>
          </template>
        </el-table-column>
      </el-table>
      <el-empty v-if="!loading && !pending.length" description="暂无待办审批" />
    </el-card>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { ElMessage } from 'element-plus'
import { workflowApi } from '@/api/workflow'
import { fmt } from '@/utils/format'
import { safeConfirm } from '@/utils/confirm'
import PageHeader from '@/components/common/PageHeader.vue'

const loading = ref(false)
const pending = ref([])

async function load() {
  loading.value = true
  try { pending.value = await workflowApi.myPending() || [] }
  catch (e) { ElMessage.error(e.message || '加载待办失败') }
  finally { loading.value = false }
}

async function handleApprove(row) {
  if (!(await safeConfirm('确认通过该审批？'))) return
  try { await workflowApi.approve(row.id, 0, ''); ElMessage.success('已通过'); load() }
  catch (e) { ElMessage.error(e.message || '操作失败') }
}

async function handleReject(row) {
  if (!(await safeConfirm('确认拒绝该审批？'))) return
  try { await workflowApi.reject(row.id, 0, ''); ElMessage.warning('已拒绝'); load() }
  catch (e) { ElMessage.error(e.message || '操作失败') }
}

onMounted(load)
</script>
