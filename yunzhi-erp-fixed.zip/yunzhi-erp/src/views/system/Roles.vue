<template>
  <div>
    <PageHeader title="角色权限" :breadcrumb="['系统管理','角色权限']" />
    <el-card>
      <el-table :data="tableData" v-loading="loading" stripe>
        <el-table-column prop="name" label="角色标识" width="140" />
        <el-table-column prop="display_name" label="角色名称" width="140" />
        <el-table-column label="权限数量" width="100" align="center"><template #default="{ row }">{{ row.permissions?.length || 0 }}</template></el-table-column>
        <el-table-column prop="description" label="说明" min-width="200" show-overflow-tooltip />
        <el-table-column label="操作" width="120" fixed="right" align="center">
          <template #default="{ row }">
            <el-button size="small" text type="primary" @click="viewPerms(row)">查看权限</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <el-dialog v-model="permsVisible" :title="`${current?.display_name} 的权限`" width="520px" align-center>
      <el-table :data="current?.permissions || []" size="small" max-height="360">
        <el-table-column prop="module" label="模块" width="140" />
        <el-table-column prop="action" label="操作" width="100" />
        <el-table-column prop="description" label="说明" min-width="160" />
      </el-table>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { rolesApi } from '@/api/system'
import { useTable } from '@/composables/useTable'
import PageHeader from '@/components/common/PageHeader.vue'

const permsVisible = ref(false)
const current = ref(null)

const { loading, tableData, load } = useTable(rolesApi.list.bind(rolesApi), { defaultPageSize: 50 })

function viewPerms(row) { current.value = row; permsVisible.value = true }

onMounted(load)
</script>
