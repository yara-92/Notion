<template>
  <div>
    <PageHeader title="报价管理" :breadcrumb="['销售CRM','报价管理']">
      <template #actions>
        <el-input v-model="keyword" placeholder="搜索报价单号/客户" prefix-icon="Search" style="width:200px" clearable @change="handleSearch" />
        <el-select v-model="filters.status" placeholder="状态" clearable style="width:120px" @change="load">
          <el-option v-for="s in statusOptions" :key="s.value" :label="s.label" :value="s.value" />
        </el-select>
        <el-button type="primary" icon="Plus" @click="openForm()">新建报价</el-button>
      </template>
    </PageHeader>

    <el-card>
      <el-table :data="tableData" v-loading="loading" stripe>
        <el-table-column prop="quote_no" label="报价单号" width="150">
          <template #default="{ row }"><span style="color:var(--el-color-primary);font-family:monospace">{{ row.quote_no }}</span></template>
        </el-table-column>
        <el-table-column label="客户" prop="customers.name" min-width="150" show-overflow-tooltip />
        <el-table-column prop="product" label="产品" min-width="140" show-overflow-tooltip />
        <el-table-column label="金额" width="130" align="right">
          <template #default="{ row }"><span style="font-weight:700">{{ fmt.money(row.amount) }}</span></template>
        </el-table-column>
        <el-table-column prop="valid_until" label="有效期至" width="110">
          <template #default="{ row }">{{ fmt.date(row.valid_until) }}</template>
        </el-table-column>
        <el-table-column label="状态" width="100" align="center">
          <template #default="{ row }">
            <StatusTag :status="row.status" :map="{ draft:{label:'草稿',type:'info'}, sent:{label:'已发送',type:'warning'}, accepted:{label:'已接受',type:'success'}, rejected:{label:'已拒绝',type:'danger'}, converted:{label:'已转订单',type:''} }" />
          </template>
        </el-table-column>
        <el-table-column label="操作" width="160" fixed="right" align="center">
          <template #default="{ row }">
            <el-button size="small" text type="primary" @click="openForm(row)">编辑</el-button>
            <el-button v-if="row.status==='accepted'" size="small" text type="success" @click="convert(row)">转订单</el-button>
          </template>
        </el-table-column>
      </el-table>
      <el-pagination style="margin-top:16px;justify-content:flex-end;display:flex"
        v-model:current-page="pagination.page" :total="pagination.total" :page-size="pagination.pageSize"
        layout="total, prev, pager, next" @current-change="handlePageChange" />
    </el-card>

    <el-dialog v-model="formVisible" :title="isEdit?'编辑报价单':'新建报价单'" width="580px" align-center destroy-on-close>
      <el-form :model="formData" ref="formRef" label-width="90px">
        <el-form-item label="客户" prop="customer_id">
          <el-select v-model="formData.customer_id" style="width:100%" filterable>
            <el-option v-for="c in customers" :key="c.id" :label="c.name" :value="c.id" />
          </el-select>
        </el-form-item>
        <el-row :gutter="16">
          <el-col :span="12"><el-form-item label="产品"><el-input v-model="formData.product" /></el-form-item></el-col>
          <el-col :span="12"><el-form-item label="金额"><el-input-number v-model="formData.amount" :min="0" :precision="2" style="width:100%" /></el-form-item></el-col>
          <el-col :span="12"><el-form-item label="有效期至"><el-date-picker v-model="formData.valid_until" type="date" style="width:100%" /></el-form-item></el-col>
          <el-col :span="12"><el-form-item label="状态">
            <el-select v-model="formData.status" style="width:100%">
              <el-option v-for="s in statusOptions" :key="s.value" :label="s.label" :value="s.value" />
            </el-select>
          </el-form-item></el-col>
        </el-row>
        <el-form-item label="备注"><el-input v-model="formData.note" type="textarea" :rows="2" /></el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="closeForm">取消</el-button>
        <el-button type="primary" :loading="formLoading" @click="submitForm">保存</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { ElMessage } from 'element-plus'
import { quotationsApi } from '@/api/crm'
import { supabase } from '@/supabase'
import { fmt } from '@/utils/format'
import { useTable } from '@/composables/useTable'
import { useForm } from '@/composables/useForm'
import PageHeader from '@/components/common/PageHeader.vue'
import StatusTag from '@/components/common/StatusTag.vue'

const keyword = ref('')
const customers = ref([])
const statusOptions = [
  { label: '草稿', value: 'draft' }, { label: '已发送', value: 'sent' },
  { label: '已接受', value: 'accepted' }, { label: '已拒绝', value: 'rejected' }, { label: '已转订单', value: 'converted' },
]

const { loading, tableData, pagination, filters, load, handlePageChange } = useTable(quotationsApi.list.bind(quotationsApi))

const {
  formRef, loading: formLoading, formData, visible: formVisible, isEdit,
  open: openForm, close: closeForm, submit: submitForm
} = useForm(
  { customer_id: null, product: '', amount: 0, valid_until: null, status: 'draft', note: '' },
  async (payload, editing, editId) => {
    if (editing) await quotationsApi.update(editId, payload)
    else await quotationsApi.create(payload)
    load()
  }
)

function handleSearch() { filters.search = keyword.value ? { column: 'quote_no', value: keyword.value } : null; pagination.page = 1; load() }

async function convert(row) {
  try { await quotationsApi.convertToOrder(row.id); ElMessage.success('已转为销售订单'); load() }
  catch (e) { ElMessage.error(e.message || '转换失败') }
}

onMounted(async () => {
  const { data } = await supabase.from('customers').select('id,name')
  customers.value = data || []
  load()
})
</script>
