<template>
  <div>
    <PageHeader title="销售订单" :breadcrumb="['销售CRM','销售订单']">
      <template #actions>
        <el-input v-model="keyword" placeholder="搜索订单号/客户" prefix-icon="Search" style="width:200px" clearable @change="handleSearch" />
        <el-select v-model="filterStatus" placeholder="状态" clearable style="width:120px" @change="load">
          <el-option v-for="s in statusOptions" :key="s.value" :label="s.label" :value="s.value" />
        </el-select>
        <el-button type="primary" icon="Plus" @click="openForm()">新建订单</el-button>
      </template>
    </PageHeader>

    <!-- Flow Steps -->
    <div class="flow-bar">
      <div v-for="(step, idx) in flowSteps" :key="step" :class="['flow-step', idx < 2 ? 'done' : idx === 2 ? 'active' : '']">
        {{ idx < 2 ? '✓ ' : '' }}{{ step }}
      </div>
    </div>

    <el-card>
      <!-- [FIX H2] 原来是纯本地硬编码数组，现改为渲染真实接口返回的 orders -->
      <el-table :data="orders" stripe v-loading="loading">
        <el-table-column prop="order_no" label="订单号" width="150" fixed>
          <template #default="{row}"><span style="color:var(--el-color-primary);font-family:monospace">{{ row.order_no }}</span></template>
        </el-table-column>
        <el-table-column label="客户" prop="customers.name" min-width="150" show-overflow-tooltip />
        <el-table-column prop="product" label="产品" min-width="140" show-overflow-tooltip />
        <el-table-column prop="qty" label="数量" width="80" align="center" />
        <el-table-column label="金额" width="130" align="right">
          <template #default="{row}"><span style="font-weight:700">{{ fmt.money(row.amount) }}</span></template>
        </el-table-column>
        <el-table-column label="下单日期" width="110">
          <template #default="{row}">{{ fmt.date(row.created_at) }}</template>
        </el-table-column>
        <el-table-column label="状态" width="90" align="center">
          <template #default="{row}">
            <el-tag :type="statusMap[row.status]?.type" size="small">{{ statusMap[row.status]?.label }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column label="操作" width="160" fixed="right" align="center">
          <template #default="{row}">
            <el-button size="small" text type="primary">详情</el-button>
            <el-button v-if="row.status==='pending'" size="small" text type="success" @click="approve(row)">审批</el-button>
            <el-button v-if="row.status==='approved'" size="small" text type="warning" @click="ship(row)">发货</el-button>
          </template>
        </el-table-column>
      </el-table>
      <el-pagination style="margin-top:16px;justify-content:flex-end;display:flex"
        v-model:current-page="pagination.page" :page-size="pagination.pageSize" :total="pagination.total"
        layout="total, prev, pager, next" @current-change="handlePageChange" />
    </el-card>

    <el-dialog v-model="formVisible" title="新建销售订单" width="580px" align-center destroy-on-close>
      <el-form :model="form" label-width="90px">
        <el-form-item label="客户" required>
          <el-select v-model="form.customer_id" style="width:100%" filterable>
            <el-option v-for="c in customers" :key="c.id" :label="c.name" :value="c.id" />
          </el-select>
        </el-form-item>
        <el-row :gutter="16">
          <el-col :span="12"><el-form-item label="产品"><el-input v-model="form.product" /></el-form-item></el-col>
          <el-col :span="12"><el-form-item label="数量"><el-input-number v-model="form.qty" :min="1" style="width:100%" /></el-form-item></el-col>
          <el-col :span="12"><el-form-item label="单价"><el-input-number v-model="form.price" :min="0" :precision="2" style="width:100%" /></el-form-item></el-col>
          <el-col :span="12"><el-form-item label="交货日期"><el-date-picker v-model="form.delivery_date" type="date" style="width:100%" /></el-form-item></el-col>
        </el-row>
        <el-form-item label="合计金额">
          <el-statistic :value="form.qty * form.price" prefix="¥" :precision="2" />
        </el-form-item>
        <el-form-item label="备注"><el-input v-model="form.note" type="textarea" :rows="2" /></el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="formVisible=false">取消</el-button>
        <el-button type="primary" :loading="submitting" @click="submitOrder">提交审批</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue'
import { ElMessage } from 'element-plus'
import { fmt } from '@/utils/format'
// [FIX H2] 引入真实的 salesOrdersApi（此前页面里从未 import 过）
import { salesOrdersApi } from '@/api/crm'
import { supabase } from '@/supabase'
import PageHeader from '@/components/common/PageHeader.vue'

const keyword = ref('')
const filterStatus = ref(null)
const loading = ref(false)
const submitting = ref(false)
const formVisible = ref(false)
const form = reactive({ customer_id: null, product: '', qty: 1, price: 0, delivery_date: null, note: '' })
const customers = ref([])
const orders = ref([])
const pagination = reactive({ page: 1, pageSize: 10, total: 0 })

const flowSteps = ['报价单', '销售订单', '审批', '发货', '收款', '开票']
const statusOptions = [
  { label: '待审批', value: 'pending' }, { label: '已审批', value: 'approved' },
  { label: '已发货', value: 'shipped' }, { label: '已完成', value: 'completed' }, { label: '已取消', value: 'cancelled' }
]
const statusMap = {
  draft: { label: '草稿', type: 'info' }, pending: { label: '待审批', type: 'warning' },
  approved: { label: '已审批', type: 'success' }, shipped: { label: '已发货', type: '' },
  completed: { label: '已完成', type: 'success' }, cancelled: { label: '已取消', type: 'danger' }
}

// [FIX H2] 之前 orders 是硬编码的 5 条假数据，现在改为从数据库加载
async function load() {
  loading.value = true
  try {
    const res = await salesOrdersApi.list({
      status: filterStatus.value || undefined,
      search: keyword.value ? { column: 'order_no', value: keyword.value } : null,
      page: pagination.page,
      pageSize: pagination.pageSize,
    })
    orders.value = res.data
    pagination.total = res.total
  } catch (e) {
    ElMessage.error(e.message || '加载订单失败')
  } finally {
    loading.value = false
  }
}

function handleSearch() { pagination.page = 1; load() }
function handlePageChange(p) { pagination.page = p; load() }

function openForm() {
  Object.assign(form, { customer_id: null, product: '', qty: 1, price: 0, delivery_date: null, note: '' })
  formVisible.value = true
}

// [FIX H2] approve/ship 此前只是改本地内存里的 status 字段，刷新页面就消失；
// 现在真正调用 salesOrdersApi.approve()/ship() 落库
async function approve(row) {
  try {
    await salesOrdersApi.approve(row.id)
    row.status = 'approved'
    ElMessage.success(`订单 ${row.order_no} 已审批通过`)
  } catch (e) { ElMessage.error(e.message || '审批失败') }
}
async function ship(row) {
  try {
    await salesOrdersApi.ship(row.id)
    row.status = 'shipped'
    ElMessage.success(`订单 ${row.order_no} 已发货`)
  } catch (e) { ElMessage.error(e.message || '发货失败') }
}
async function submitOrder() {
  if (!form.customer_id) { ElMessage.warning('请选择客户'); return }
  submitting.value = true
  try {
    await salesOrdersApi.create({
      customer_id: form.customer_id,
      product: form.product,
      qty: form.qty,
      amount: form.qty * form.price,
      note: form.note,
      status: 'pending',
    })
    ElMessage.success('销售订单已提交审批')
    formVisible.value = false
    load()
  } catch (e) {
    ElMessage.error(e.message || '提交失败')
  } finally {
    submitting.value = false
  }
}

onMounted(async () => {
  const { data } = await supabase.from('customers').select('id,name')
  customers.value = data || []
  load()
})
</script>

<style scoped lang="scss">
.flow-bar { display:flex; align-items:center; gap:6px; margin-bottom:16px; flex-wrap:wrap; }
.flow-step {
  padding:6px 14px; border-radius:6px; font-size:12px; font-weight:500;
  background:var(--el-fill-color-light); color:var(--el-text-color-secondary); border:1px solid var(--el-border-color);
  &.active { background:var(--el-color-primary-light-9); color:var(--el-color-primary); border-color:var(--el-color-primary-light-5); }
  &.done { background:var(--el-color-success-light-9); color:var(--el-color-success); border-color:var(--el-color-success-light-5); }
}
</style>
