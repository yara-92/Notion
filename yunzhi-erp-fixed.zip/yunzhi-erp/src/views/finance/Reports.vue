<template>
  <div>
    <PageHeader title="财务报表" :breadcrumb="['财务管理','财务报表']">
      <template #actions>
        <el-date-picker v-model="period" type="month" placeholder="选择月份" @change="load" style="width:140px" />
      </template>
    </PageHeader>

    <el-card v-loading="loading">
      <el-table :data="rows">
        <el-table-column prop="account_code" label="科目编码" width="120" />
        <el-table-column prop="account_name" label="科目名称" min-width="160" />
        <el-table-column label="期初余额" width="130" align="right"><template #default="{ row }">{{ fmt.money(row.opening_balance) }}</template></el-table-column>
        <el-table-column label="本期借方" width="130" align="right"><template #default="{ row }">{{ fmt.money(row.debit) }}</template></el-table-column>
        <el-table-column label="本期贷方" width="130" align="right"><template #default="{ row }">{{ fmt.money(row.credit) }}</template></el-table-column>
        <el-table-column label="期末余额" width="130" align="right"><template #default="{ row }"><strong>{{ fmt.money(row.closing_balance) }}</strong></template></el-table-column>
      </el-table>
      <el-empty v-if="!loading && !rows.length" description="暂无数据，请选择月份" />
    </el-card>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { ElMessage } from 'element-plus'
import dayjs from 'dayjs'
import { ledgerApi } from '@/api/finance'
import { fmt } from '@/utils/format'
import PageHeader from '@/components/common/PageHeader.vue'

const period = ref(new Date())
const loading = ref(false)
const rows = ref([])

async function load() {
  loading.value = true
  try {
    const d = dayjs(period.value)
    rows.value = await ledgerApi.getTrialBalance(d.year(), d.month() + 1) || []
  } catch (e) { ElMessage.error(e.message || '加载报表失败') }
  finally { loading.value = false }
}

onMounted(load)
</script>
