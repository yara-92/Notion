<template>
  <div>
    <PageHeader title="应付账款" :breadcrumb="['财务管理','应付账款']">
      <template #actions>
        <el-select v-model="filters.status" placeholder="状态" clearable style="width:120px" @change="load">
          <el-option label="未付款" value="unpaid" /><el-option label="已付清" value="paid" />
        </el-select>
      </template>
    </PageHeader>

    <el-card>
      <el-table :data="tableData" v-loading="loading" stripe>
        <el-table-column label="供应商" prop="suppliers.name" min-width="160" show-overflow-tooltip />
        <el-table-column label="应付金额" width="130" align="right">
          <template #default="{ row }"><span style="font-weight:700">{{ fmt.money(row.amount) }}</span></template>
        </el-table-column>
        <el-table-column prop="due_date" label="到期日" width="110">
          <template #default="{ row }">{{ fmt.date(row.due_date) }}</template>
        </el-table-column>
        <el-table-column label="状态" width="100" align="center">
          <template #default="{ row }"><StatusTag :status="row.status" :map="{ unpaid:{label:'未付款',type:'warning'}, paid:{label:'已付清',type:'success'} }" /></template>
        </el-table-column>
        <el-table-column label="操作" width="120" fixed="right" align="center">
          <template #default="{ row }">
            <el-button v-if="row.status==='unpaid'" size="small" text type="success" @click="pay(row)">登记付款</el-button>
          </template>
        </el-table-column>
      </el-table>
      <el-pagination style="margin-top:16px;justify-content:flex-end;display:flex"
        v-model:current-page="pagination.page" :total="pagination.total" :page-size="pagination.pageSize"
        layout="total, prev, pager, next" @current-change="handlePageChange" />
    </el-card>
  </div>
</template>

<script setup>
import { onMounted } from 'vue'
import { ElMessage } from 'element-plus'
import { payablesApi } from '@/api/finance'
import { fmt } from '@/utils/format'
import { safeConfirm } from '@/utils/confirm'
import { useTable } from '@/composables/useTable'
import PageHeader from '@/components/common/PageHeader.vue'
import StatusTag from '@/components/common/StatusTag.vue'

const { loading, tableData, pagination, filters, load, handlePageChange } = useTable(payablesApi.list.bind(payablesApi))

async function pay(row) {
  if (!(await safeConfirm(`确认已支付 ${fmt.money(row.amount)} 给该供应商？`))) return
  try { await payablesApi.update(row.id, { status: 'paid', paid_at: new Date().toISOString() }); ElMessage.success('付款已登记'); load() }
  catch (e) { ElMessage.error(e.message || '操作失败') }
}

onMounted(load)
</script>
