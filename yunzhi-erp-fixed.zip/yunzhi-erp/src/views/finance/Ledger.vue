<template>
  <div>
    <PageHeader title="总账凭证" :breadcrumb="['财务管理','总账凭证']">
      <template #actions>
        <el-select v-model="filters.status" placeholder="状态" clearable style="width:120px" @change="load">
          <el-option label="草稿" value="draft" /><el-option label="已过账" value="posted" />
        </el-select>
      </template>
    </PageHeader>

    <el-card>
      <el-table :data="tableData" v-loading="loading" stripe row-key="id">
        <el-table-column type="expand">
          <template #default="{ row }">
            <el-table :data="row.lines" size="small" style="margin:8px 24px;width:calc(100% - 48px)">
              <el-table-column label="科目" prop="accounts.name" width="160" />
              <el-table-column label="科目编码" prop="accounts.code" width="100" />
              <el-table-column label="借方" width="120" align="right">
                <template #default="{ row: l }">{{ l.debit ? fmt.money(l.debit) : '' }}</template>
              </el-table-column>
              <el-table-column label="贷方" width="120" align="right">
                <template #default="{ row: l }">{{ l.credit ? fmt.money(l.credit) : '' }}</template>
              </el-table-column>
              <el-table-column label="摘要" prop="description" min-width="160" />
            </el-table>
          </template>
        </el-table-column>
        <el-table-column prop="voucher_no" label="凭证号" width="150" />
        <el-table-column prop="voucher_date" label="日期" width="110">
          <template #default="{ row }">{{ fmt.date(row.voucher_date) }}</template>
        </el-table-column>
        <el-table-column label="制单人" prop="preparer.name" width="110" />
        <el-table-column label="金额" width="130" align="right">
          <template #default="{ row }">{{ fmt.money(row.amount) }}</template>
        </el-table-column>
        <el-table-column label="状态" width="100" align="center">
          <template #default="{ row }"><StatusTag :status="row.status" :map="{ draft:{label:'草稿',type:'info'}, posted:{label:'已过账',type:'success'} }" /></template>
        </el-table-column>
        <el-table-column label="操作" width="120" fixed="right" align="center">
          <template #default="{ row }">
            <el-button v-if="row.status==='draft'" size="small" text type="success" @click.stop="post(row)">过账</el-button>
          </template>
        </el-table-column>
      </el-table>
      <el-pagination style="margin-top:16px;justify-content:flex-end;display:flex"
        v-model:current-page="pagination.page" :total="pagination.total" :page-size="pagination.pageSize"
        layout="total, prev, pager, next" @current-change="handlePageChange" />
    </el-card>
  </div>
</template>

<script setup>
import { onMounted } from 'vue'
import { ElMessage } from 'element-plus'
import { ledgerApi } from '@/api/finance'
import { fmt } from '@/utils/format'
import { safeConfirm } from '@/utils/confirm'
import { useTable } from '@/composables/useTable'
import PageHeader from '@/components/common/PageHeader.vue'
import StatusTag from '@/components/common/StatusTag.vue'

const { loading, tableData, pagination, filters, load, handlePageChange } = useTable(ledgerApi.list.bind(ledgerApi))

async function post(row) {
  if (!(await safeConfirm(`确认过账凭证 ${row.voucher_no}？过账后不可修改。`))) return
  try { await ledgerApi.post(row.id); ElMessage.success('已过账'); load() }
  catch (e) { ElMessage.error(e.message || '操作失败') }
}

onMounted(load)
</script>
