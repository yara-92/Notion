<template>
  <div>
    <PageHeader title="应收账款" :breadcrumb="['财务管理','应收账款']">
      <template #actions>
        <el-select v-model="filters.status" placeholder="状态" clearable style="width:120px" @change="load">
          <el-option v-for="s in statusOptions" :key="s.value" :label="s.label" :value="s.value" />
        </el-select>
      </template>
    </PageHeader>

    <el-card>
      <el-table :data="tableData" v-loading="loading" stripe>
        <el-table-column label="客户" prop="customers.name" min-width="150" show-overflow-tooltip />
        <el-table-column label="关联订单" prop="sales_orders.order_no" width="150" />
        <el-table-column label="应收金额" width="130" align="right">
          <template #default="{ row }"><span style="font-weight:700">{{ fmt.money(row.amount) }}</span></template>
        </el-table-column>
        <el-table-column label="已收金额" width="130" align="right">
          <template #default="{ row }">{{ fmt.money(row.received_amount) }}</template>
        </el-table-column>
        <el-table-column prop="due_date" label="到期日" width="110">
          <template #default="{ row }">{{ fmt.date(row.due_date) }}</template>
        </el-table-column>
        <el-table-column label="状态" width="100" align="center">
          <template #default="{ row }"><StatusTag :status="row.status" :map="statusMap" /></template>
        </el-table-column>
        <el-table-column label="操作" width="120" fixed="right" align="center">
          <template #default="{ row }">
            <el-button v-if="row.status!=='paid'" size="small" text type="success" @click="collect(row)">登记收款</el-button>
          </template>
        </el-table-column>
      </el-table>
      <el-pagination style="margin-top:16px;justify-content:flex-end;display:flex"
        v-model:current-page="pagination.page" :total="pagination.total" :page-size="pagination.pageSize"
        layout="total, prev, pager, next" @current-change="handlePageChange" />
    </el-card>
  </div>
</template>

<script setup>
import { onMounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { receivablesApi } from '@/api/finance'
import { fmt } from '@/utils/format'
import { useTable } from '@/composables/useTable'
import PageHeader from '@/components/common/PageHeader.vue'
import StatusTag from '@/components/common/StatusTag.vue'

const statusOptions = [
  { label: '未收款', value: 'unpaid' }, { label: '部分收款', value: 'partial' },
  { label: '已收清', value: 'paid' }, { label: '已逾期', value: 'overdue' },
]
const statusMap = {
  unpaid: { label: '未收款', type: 'warning' }, partial: { label: '部分收款', type: '' },
  paid: { label: '已收清', type: 'success' }, overdue: { label: '已逾期', type: 'danger' },
}

const { loading, tableData, pagination, filters, load, handlePageChange } = useTable(receivablesApi.list.bind(receivablesApi))

async function collect(row) {
  try {
    const { value } = await ElMessageBox.prompt('请输入本次收款金额', '登记收款', { inputPlaceholder: '金额', inputType: 'number' })
    const received = Number(row.received_amount || 0) + Number(value)
    await receivablesApi.update(row.id, {
      received_amount: received,
      status: received >= row.amount ? 'paid' : 'partial'
    })
    ElMessage.success('收款已登记')
    load()
  } catch { /* 用户取消 */ }
}

onMounted(load)
</script>
