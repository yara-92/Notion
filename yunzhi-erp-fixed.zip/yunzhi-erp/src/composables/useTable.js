import { ref, reactive } from 'vue'
import { ElMessage } from 'element-plus'
import { safeConfirm } from '@/utils/confirm'

export function useTable(fetchFn, { defaultPageSize = 20 } = {}) {
  const loading = ref(false)
  const tableData = ref([])
  const pagination = reactive({ page: 1, pageSize: defaultPageSize, total: 0 })
  const filters = reactive({})

  async function load(params = {}) {
    loading.value = true
    try {
      const result = await fetchFn({ ...filters, ...params, page: pagination.page, pageSize: pagination.pageSize })
      tableData.value = result.data || []
      pagination.total = result.total || 0
    } catch (e) {
      ElMessage.error(e.message || '加载失败')
    } finally {
      loading.value = false
    }
  }

  function handlePageChange(p) { pagination.page = p; load() }
  function handleSizeChange(s) { pagination.pageSize = s; pagination.page = 1; load() }
  function handleFilterChange(f) { Object.assign(filters, f); pagination.page = 1; load() }

  // [FIX C7/M10] 原来直接 await ElMessageBox.confirm(...) 不做 try/catch，用户点"取消"
  // 会抛出未捕获的 Promise rejection；同时调用方也完全不知道删除是成功/失败/取消，
  // 现在统一用 safeConfirm() 并返回 true/false，方便调用方感知结果。
  async function handleDelete(id, deleteFn, msg = '确定删除该记录？') {
    if (!(await safeConfirm(msg, '警告'))) return false
    loading.value = true
    try {
      await deleteFn(id)
      ElMessage.success('删除成功')
      load()
      return true
    } catch (e) {
      ElMessage.error(e.message || '删除失败')
      return false
    } finally {
      loading.value = false
    }
  }

  return { loading, tableData, pagination, filters, load, handlePageChange, handleSizeChange, handleFilterChange, handleDelete }
}
