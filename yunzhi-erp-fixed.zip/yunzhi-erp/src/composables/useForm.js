import { ref, reactive } from 'vue'
import { ElMessage } from 'element-plus'
import { safeValidate } from '@/utils/confirm'

export function useForm(defaultData = {}, submitFn) {
  const formRef = ref()
  const loading = ref(false)
  const formData = reactive({ ...defaultData })
  const visible = ref(false)
  const isEdit = ref(false)
  const editId = ref(null)

  function open(data = null) {
    isEdit.value = !!data
    editId.value = data?.id || null
    Object.assign(formData, { ...defaultData, ...(data || {}) })
    visible.value = true
  }

  function close() { visible.value = false; formRef.value?.resetFields() }

  async function submit() {
    // [FIX C7] formRef.value.validate() 校验失败时会 reject，原来直接 await 没有
    // try/catch，每次校验失败都会抛出一条未捕获的 Promise rejection。
    if (!(await safeValidate(formRef))) return false
    loading.value = true
    try {
      const payload = { ...formData }
      await submitFn(payload, isEdit.value, editId.value)
      ElMessage.success(isEdit.value ? '修改成功' : '创建成功')
      close()
      return true
    } catch (e) {
      ElMessage.error(e.message || '操作失败')
      return false
    } finally {
      loading.value = false
    }
  }

  return { formRef, loading, formData, visible, isEdit, open, close, submit }
}
