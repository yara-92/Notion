import { BaseApi } from './base'
import { storageApi } from '@/supabase'

class AnnouncementsApi extends BaseApi {
  constructor() { super('announcements') }
  async list(p = {}) { return super.list({ ...p, select: '*, author:author_id(name)' }) }
  async publish(id) { return this.update(id, { status: 'published', published_at: new Date().toISOString() }) }
}

class MeetingsApi extends BaseApi {
  constructor() { super('meetings') }
  async list(p = {}) { return super.list({ ...p, select: '*, organizer:organizer_id(name)', order: { column: 'start_time', ascending: true } }) }
}

class TodosApi extends BaseApi {
  constructor() { super('todos') }
  async list(p = {}) { return super.list({ ...p, order: { column: 'due_date', ascending: true } }) }
  async toggle(id, done) { return this.update(id, { done }) }
}

class KnowledgeApi extends BaseApi {
  constructor() { super('knowledge_articles') }
  async list(p = {}) { return super.list({ ...p, select: '*, author:author_id(name)' }) }
}

class FilesApi extends BaseApi {
  constructor() { super('files') }
  async list(p = {}) { return super.list({ ...p, select: '*, uploader:uploaded_by(name)' }) }
  async upload(file, folder = 'files') {
    const path = `${folder}/${Date.now()}_${file.name}`
    await storageApi.upload('files', path, file)
    const url = storageApi.getPublicUrl('files', path)
    return this.create({ name: file.name, path, url, size: file.size })
  }
}

export const announcementsApi = new AnnouncementsApi()
export const meetingsApi = new MeetingsApi()
export const todosApi = new TodosApi()
export const knowledgeApi = new KnowledgeApi()
export const filesApi = new FilesApi()
