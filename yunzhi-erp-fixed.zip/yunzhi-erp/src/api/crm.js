import { BaseApi } from './base'
import { supabase } from '@/supabase'

class CustomersApi extends BaseApi {
  constructor() { super('customers') }
  async list(params = {}) {
    return super.list({ ...params, select: '*, owner:owner_id(name)' })
  }
  async getTimeline(customerId) {
    const { data } = await supabase.from('follow_records')
      .select('*, user:user_id(name)').eq('customer_id', customerId)
      .order('follow_date', { ascending: false })
    return data
  }
  async addFollow(record) {
    const { data, error } = await supabase.from('follow_records').insert(record).select().single()
    if (error) throw error
    return data
  }
}

class OpportunitiesApi extends BaseApi {
  constructor() { super('opportunities') }
  async list(params = {}) {
    return super.list({ ...params, select: '*, customers(name), owner:owner_id(name)' })
  }
  // [FIX C8] 原逻辑 .eq('stage','won').neq('stage','lost') 直接把结果限定为只有"已成交"，
  // 后面的 neq 是永远为真的冗余条件；漏斗本该统计每个阶段的数量，而不是只返回一个阶段。
  // 改为拉取全部商机后按阶段分组计数/求和。
  async getFunnel() {
    const { data, error } = await supabase.from('opportunities').select('stage, amount')
    if (error) throw error
    const stages = ['lead', 'prospect', 'qualified', 'proposal', 'negotiation', 'won']
    return stages.map(stage => ({
      stage,
      count: data.filter(o => o.stage === stage).length,
      amount: data.filter(o => o.stage === stage).reduce((sum, o) => sum + (o.amount || 0), 0)
    }))
  }
}

class SalesOrdersApi extends BaseApi {
  constructor() { super('sales_orders') }
  async list(params = {}) {
    return super.list({ ...params, select: '*, customers(name), items:sales_order_items(*, products(name))' })
  }
  async approve(id) { return this.update(id, { status: 'approved' }) }
  async ship(id) { return this.update(id, { status: 'shipped' }) }
}

export const customersApi = new CustomersApi()
export const opportunitiesApi = new OpportunitiesApi()
export const salesOrdersApi = new SalesOrdersApi()

// [新增] 报价管理模块此前是空占位页，现补充对应API
class QuotationsApi extends BaseApi {
  constructor() { super('quotations') }
  async list(p = {}) { return super.list({ ...p, select: '*, customers(name), owner:owner_id(name)' }) }
  async convertToOrder(id) { return this.update(id, { status: 'converted' }) }
}
export const quotationsApi = new QuotationsApi()
