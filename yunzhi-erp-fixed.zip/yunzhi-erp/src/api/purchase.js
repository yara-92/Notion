import { BaseApi } from './base'

class SuppliersApi extends BaseApi {
  constructor() { super('suppliers') }
}

class RequisitionsApi extends BaseApi {
  constructor() { super('purchase_requisitions') }
  async list(p = {}) { return super.list({ ...p, select: '*, applicant:applicant_id(name), departments(name)' }) }
  async approve(id) { return this.update(id, { status: 'approved' }) }
  async reject(id, reason) { return this.update(id, { status: 'rejected', reject_reason: reason }) }
}

class PurchaseOrdersApi extends BaseApi {
  constructor() { super('purchase_orders') }
  async list(p = {}) { return super.list({ ...p, select: '*, suppliers(name), items:purchase_order_items(*, products(name))' }) }
  async approve(id) { return this.update(id, { status: 'approved' }) }
  async receive(id) { return this.update(id, { status: 'received', received_at: new Date().toISOString() }) }
}

export const suppliersApi = new SuppliersApi()
export const requisitionsApi = new RequisitionsApi()
export const purchaseOrdersApi = new PurchaseOrdersApi()
