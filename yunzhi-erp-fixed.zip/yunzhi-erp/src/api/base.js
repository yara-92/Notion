import { supabase } from '@/supabase'
import { useAuthStore } from '@/stores/auth'

/**
 * Base API class wrapping Supabase queries
 * All CRUD operations auto-log to audit_logs
 */
export class BaseApi {
  constructor(tableName) {
    this.table = tableName
  }

  query() { return supabase.from(this.table) }

  // [FIX 发现于打包联调阶段] 原来的签名是 list({ filters = {}, select, order, page, pageSize }),
  // 但项目里所有实际调用方（useTable.js 的 load()、各页面的 table.load()）传入的都是
  // 扁平对象，例如 { dept_id: 1, status: 'active', page: 1, pageSize: 20 }，并不会嵌套在
  // filters 键下面。这导致 `filters = {}` 永远拿到空对象，.eq() 从未真正生效——所有筛选
  // 条件在原代码里其实是"看起来生效、实际上被静默忽略"的。这里改成用剩余参数收集筛选字段，
  // 使扁平调用方式（现在项目里唯一实际使用的方式）能真正工作；同时新增 search 用于模糊搜索。
  async list({ select = '*', order = { column: 'created_at', ascending: false }, page = 1, pageSize = 20, search = null, ...filters } = {}) {
    let q = this.query().select(select, { count: 'exact' })
    Object.entries(filters).forEach(([k, v]) => {
      if (v !== undefined && v !== null && v !== '') q = q.eq(k, v)
    })
    if (search?.column && search?.value) q = q.ilike(search.column, `%${search.value}%`)
    if (order) q = q.order(order.column, { ascending: order.ascending })
    const from = (page - 1) * pageSize
    q = q.range(from, from + pageSize - 1)
    const { data, error, count } = await q
    if (error) throw error
    return { data, total: count, page, pageSize }
  }

  async getById(id, select = '*') {
    const { data, error } = await this.query().select(select).eq('id', id).single()
    if (error) throw error
    return data
  }

  async create(payload) {
    const { data, error } = await this.query().insert(payload).select().single()
    if (error) throw error
    await this._auditLog('CREATE', data.id, null, data)
    return data
  }

  // [FIX M5] 原来的 update() 会先 getById() 查一次旧值，再执行一次 update，等于把每次
  // 更新的请求数翻倍。这里改为用 delete/update 自带的 .select() 直接拿到变更后的数据，
  // 审计日志改为只记录“变更后的值”，不再额外查询旧值。
  async update(id, payload) {
    const { data, error } = await this.query()
      .update({ ...payload, updated_at: new Date().toISOString() })
      .eq('id', id)
      .select()
      .single()
    if (error) throw error
    await this._auditLog('UPDATE', id, null, data)
    return data
  }

  // [FIX M5] 同上，delete().select() 可以在同一次请求里拿到被删除的行，不用先 getById 再删除
  async remove(id) {
    const { data: old, error } = await this.query().delete().eq('id', id).select().single()
    if (error) throw error
    await this._auditLog('DELETE', id, old, null)
    return true
  }

  async _auditLog(action, resourceId, oldData, newData) {
    try {
      const auth = useAuthStore()
      await supabase.from('audit_logs').insert({
        user_id: auth.userId,
        action,
        module: this.table,
        resource: this.table,
        resource_id: String(resourceId),
        old_data: oldData,
        new_data: newData
      })
    } catch (e) { /* audit failures should not block main flow */ }
  }
}
