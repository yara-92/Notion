import { BaseApi } from './base'
import { supabase } from '@/supabase'

class InventoryApi extends BaseApi {
  constructor() { super('inventory') }
  async list(p = {}) {
    return super.list({ ...p, select: '*, products(sku,name,category_id), warehouses(name)' })
  }
  // [FIX C6] supabase-js 客户端没有 .raw() 方法，原代码会直接抛出
  // "supabase.raw is not a function"。PostgREST 的 filter 值默认按字面量处理，无法直接
  // 比较两个列，这里改为拉取后在客户端比较；数据量大时建议换成 RPC + SQL 视图。
  async getAlerts() {
    const { data, error } = await supabase.from('inventory').select('*, products(name,sku)')
    if (error) throw error
    return (data || []).filter(row => row.qty <= row.safety_qty)
  }
  async transfer(from, to, productId, qty) {
    const { data, error } = await supabase.rpc('transfer_stock', { p_from: from, p_to: to, p_product: productId, p_qty: qty })
    if (error) throw error
    return data
  }
}

class TransactionsApi extends BaseApi {
  constructor() { super('inventory_transactions') }
  async list(p = {}) {
    return super.list({ ...p, select: '*, warehouses(name), products(name)' })
  }
  async inbound(payload) {
    const { data, error } = await supabase.rpc('process_inbound', payload)
    if (error) throw error
    return data
  }
  async outbound(payload) {
    const { data, error } = await supabase.rpc('process_outbound', payload)
    if (error) throw error
    return data
  }
}

export const inventoryApi = new InventoryApi()
export const transactionsApi = new TransactionsApi()

// [新增] 仓库管理 / 库存盘点模块此前是空占位页，现补充对应API
class WarehousesApi extends BaseApi {
  constructor() { super('warehouses') }
}
class StocktakeApi extends BaseApi {
  constructor() { super('stocktakes') }
  async list(p = {}) { return super.list({ ...p, select: '*, warehouses(name)' }) }
  async start(id) { return this.update(id, { status: 'in_progress', started_at: new Date().toISOString() }) }
  async complete(id) { return this.update(id, { status: 'completed', completed_at: new Date().toISOString() }) }
}
export const warehousesApi = new WarehousesApi()
export const stocktakeApi = new StocktakeApi()
