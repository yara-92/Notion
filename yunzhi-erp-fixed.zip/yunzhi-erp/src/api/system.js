import { BaseApi } from './base'
import { supabase } from '@/supabase'

class RolesApi extends BaseApi {
  constructor() { super('roles') }
  async list(p = {}) { return super.list({ ...p, select: '*, permissions(*)' }) }
}

class DictApi extends BaseApi {
  constructor() { super('dict_items') }
  async list(p = {}) { return super.list({ ...p, order: { column: 'sort_order', ascending: true } }) }
}

class LogsApi {
  async list({ page = 1, pageSize = 20, ...filters } = {}) {
    let q = supabase.from('audit_logs').select('*, user:user_id(name)', { count: 'exact' })
    Object.entries(filters).forEach(([k, v]) => { if (v !== undefined && v !== null && v !== '') q = q.eq(k, v) })
    q = q.order('created_at', { ascending: false })
    const from = (page - 1) * pageSize
    q = q.range(from, from + pageSize - 1)
    const { data, error, count } = await q
    if (error) throw error
    return { data, total: count, page, pageSize }
  }
}

class SettingsApi {
  async get() {
    const { data, error } = await supabase.from('system_config').select('*').eq('id', 1).single()
    if (error) throw error
    return data
  }
  async update(payload) {
    const { data, error } = await supabase.from('system_config').update(payload).eq('id', 1).select().single()
    if (error) throw error
    return data
  }
}

export const rolesApi = new RolesApi()
export const dictApi = new DictApi()
export const logsApi = new LogsApi()
export const settingsApi = new SettingsApi()
